-- ============================================================================
-- CotizaFácil · esquema completo do banco (Supabase / Postgres)
-- Rode no SQL Editor do Supabase, na ordem, de uma vez só.
-- ============================================================================

create extension if not exists "pgcrypto";

-- ---------------------------------------------------------------------------
-- 1. PERFIS (usuários)  · nombre, correo, teléfono, idioma, plan, suscripción
-- ---------------------------------------------------------------------------
create table if not exists public.profiles (
  id                  uuid primary key references auth.users (id) on delete cascade,
  name                text,
  email               text,
  phone               text,
  language            text not null default 'pt'     check (language in ('pt','es')),
  plan                text not null default 'free'   check (plan in ('free','starter','complete','growth')),
  billing_cycle       text not null default 'monthly' check (billing_cycle in ('monthly','annual')),
  subscription_status text not null default 'inactive'
                      check (subscription_status in ('active','past_due','canceled','inactive')),
  store_name          text,
  store_phone         text,
  store_logo          text,                          -- data URL base64 ou URL pública
  next_charge_at      timestamptz,
  reminder_sent_at    timestamptz,                   -- evita e-mail duplicado
  provider_customer_id    text,                      -- cus_xxx (Stripe) / payer_id (MP)
  provider_subscription_id text,                     -- sub_xxx / preapproval id
  created_at          timestamptz not null default now(),
  updated_at          timestamptz not null default now()
);

-- Cria o perfil automaticamente após o cadastro (e-mail/senha ou Google)
create or replace function public.handle_new_user()
returns trigger language plpgsql security definer set search_path = public as $$
begin
  insert into public.profiles (id, name, email, language, store_name)
  values (
    new.id,
    coalesce(new.raw_user_meta_data->>'full_name', split_part(new.email,'@',1)),
    new.email,
    coalesce(new.raw_user_meta_data->>'language','pt'),
    coalesce(new.raw_user_meta_data->>'store_name','')
  )
  on conflict (id) do nothing;
  return new;
end; $$;

drop trigger if exists on_auth_user_created on auth.users;
create trigger on_auth_user_created
after insert on auth.users
for each row execute function public.handle_new_user();

-- ---------------------------------------------------------------------------
-- 2. CLIENTES · nombre, teléfono, observaciones, id do usuário
-- ---------------------------------------------------------------------------
create table if not exists public.clients (
  id         uuid primary key default gen_random_uuid(),
  user_id    uuid not null references auth.users (id) on delete cascade,
  name       text not null,
  phone      text not null,
  notes      text default '',
  created_at timestamptz not null default now()
);
create index if not exists clients_user_idx on public.clients (user_id, created_at desc);

-- ---------------------------------------------------------------------------
-- 3. ORÇAMENTOS · dados do pedido, valor, cliente, data de entrega, status
-- ---------------------------------------------------------------------------
create table if not exists public.quotes (
  id             uuid primary key default gen_random_uuid(),
  user_id        uuid not null references auth.users (id) on delete cascade,
  client_id      uuid references public.clients (id) on delete set null,
  customer_name  text not null,
  customer_phone text not null,
  product        text not null check (product in ('torta','bolo','doces','pao','outro')),
  size           text default '',
  flavor         text default '',
  filling        text default '',
  decoration     text default '',
  message        text default '',
  delivery_date  date,
  delivery_time  text,
  value          numeric(12,2) not null default 0,
  status         text not null default 'pending' check (status in ('pending','paid','delivered')),
  store_name     text default '',
  created_at     timestamptz not null default now()
);
create index if not exists quotes_user_created_idx on public.quotes (user_id, created_at desc);
create index if not exists quotes_user_delivery_idx on public.quotes (user_id, delivery_date);

-- ---------------------------------------------------------------------------
-- 4. PAGAMENTOS · id, valor, data, status, id do usuário
-- ---------------------------------------------------------------------------
create table if not exists public.payments (
  id                  uuid primary key default gen_random_uuid(),
  user_id             uuid not null references auth.users (id) on delete cascade,
  amount              numeric(12,2) not null,
  currency            text not null default 'BRL',
  status              text not null default 'pending' check (status in ('paid','pending','failed','refunded')),
  provider            text not null default 'manual' check (provider in ('stripe','mercadopago','manual')),
  provider_payment_id text,
  plan_id             text,
  billing_cycle       text,
  paid_at             timestamptz not null default now(),
  unique (provider, provider_payment_id)
);
create index if not exists payments_user_idx on public.payments (user_id, paid_at desc);

-- ---------------------------------------------------------------------------
-- 5. ASSINATURAS (histórico de eventos do gateway)
-- ---------------------------------------------------------------------------
create table if not exists public.subscriptions (
  id                   uuid primary key default gen_random_uuid(),
  user_id              uuid not null references auth.users (id) on delete cascade,
  plan_id              text not null,
  billing_cycle        text not null default 'monthly',
  status               text not null default 'inactive',
  provider             text not null default 'manual',
  provider_id          text,
  current_period_end   timestamptz,
  canceled_at          timestamptz,
  raw_event            jsonb,
  created_at           timestamptz not null default now()
);
create index if not exists subscriptions_user_idx on public.subscriptions (user_id, created_at desc);

-- ============================================================================
-- 6. LIMITE DO PLANO GRATUITO (5 orçamentos/mês) — validado no SERVIDOR
-- ============================================================================
create or replace function public.quote_limit_for(p_plan text)
returns integer language sql immutable as $$
  select case when p_plan = 'free' then 5 else null end;
$$;

-- Quantos orçamentos o usuário criou no mês corrente
create or replace function public.quotes_used_this_month(p_user uuid)
returns integer language sql stable security definer set search_path = public as $$
  select count(*)::int from public.quotes
  where user_id = p_user
    and created_at >= date_trunc('month', now())
    and created_at <  date_trunc('month', now()) + interval '1 month';
$$;

-- Função pública para o app mostrar "3 de 5 usados" no cabeçalho
create or replace function public.my_quota()
returns table (plan text, used int, quota int) language sql stable security definer set search_path = public as $$
  select p.plan,
         public.quotes_used_this_month(p.id) as used,
         public.quote_limit_for(p.plan)      as quota
  from public.profiles p where p.id = auth.uid();
$$;

-- Bloqueia o 6º orçamento do plano gratuito direto no banco (não dá para burlar pela UI)
create or replace function public.enforce_quote_limit()
returns trigger language plpgsql security definer set search_path = public as $$
declare v_plan text; v_limit int; v_used int;
begin
  select plan into v_plan from public.profiles where id = new.user_id;
  v_limit := public.quote_limit_for(coalesce(v_plan,'free'));
  if v_limit is null then return new; end if;         -- planos pagos: ilimitado
  v_used := public.quotes_used_this_month(new.user_id);
  if v_used >= v_limit then
    raise exception 'free_limit_reached' using
      hint = 'Limite de 5 orçamentos/mês do plano gratuito atingido. Faça upgrade para continuar.';
  end if;
  return new;
end; $$;

drop trigger if exists quotes_enforce_limit on public.quotes;
create trigger quotes_enforce_limit
before insert on public.quotes
for each row execute function public.enforce_quote_limit();

-- ============================================================================
-- 7. ROW LEVEL SECURITY — cada usuário só vê os próprios dados
-- ============================================================================
alter table public.profiles      enable row level security;
alter table public.clients       enable row level security;
alter table public.quotes        enable row level security;
alter table public.payments      enable row level security;
alter table public.subscriptions enable row level security;

-- profiles
drop policy if exists profiles_select on public.profiles;
create policy profiles_select on public.profiles for select using (auth.uid() = id);
drop policy if exists profiles_update on public.profiles;
create policy profiles_update on public.profiles for update using (auth.uid() = id) with check (auth.uid() = id);
-- (o INSERT é feito pelo trigger handle_new_user; plan/status só o service_role altera)

-- clients
drop policy if exists clients_all on public.clients;
create policy clients_all on public.clients for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- quotes (o trigger do limite roda mesmo com RLS, pois é no banco)
drop policy if exists quotes_all on public.quotes;
create policy quotes_all on public.quotes for all
  using (auth.uid() = user_id) with check (auth.uid() = user_id);

-- payments e subscriptions: leitura pelo dono; escrita apenas via service_role (webhooks)
drop policy if exists payments_select on public.payments;
create policy payments_select on public.payments for select using (auth.uid() = user_id);
drop policy if exists subscriptions_select on public.subscriptions;
create policy subscriptions_select on public.subscriptions for select using (auth.uid() = user_id);

-- ============================================================================
-- 8. E-MAIL DE LEMBRETE (3 dias antes do vencimento) — consulta do cron
-- ============================================================================
create or replace view public.subscriptions_due_in_3_days as
select p.id, p.name, p.email, p.language, p.plan, p.billing_cycle,
       p.next_charge_at, p.store_name
from public.profiles p
where p.subscription_status in ('active','past_due')
  and p.next_charge_at is not null
  and p.next_charge_at::date <= (now() + interval '3 days')::date
  and p.next_charge_at::date >= now()::date
  and (p.reminder_sent_at is null or p.reminder_sent_at < now() - interval '20 days');
