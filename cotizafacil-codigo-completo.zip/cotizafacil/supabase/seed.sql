-- ============================================================================
-- CotizaFácil · dados de exemplo (OPCIONAL)
-- Rode DEPOIS do schema.sql. Substitua <SEU_USER_ID> pelo id do seu usuário
-- (Supabase → Authentication → Users → coluna "id").
-- ============================================================================

-- Ajuste estas duas linhas:
\set uid '00000000-0000-0000-0000-000000000000'

-- Perfil de exemplo (com planos avançados, para testar telas sem gateway)
update public.profiles
set store_name = 'Padaria Pão Quentinho',
    store_phone = '(11) 99999-0000',
    plan = 'complete',
    subscription_status = 'active',
    billing_cycle = 'monthly',
    next_charge_at = now() + interval '25 days'
where id = :'uid';

-- Clientes de exemplo
insert into public.clients (user_id, name, phone, notes) values
  (:'uid', 'Maria Silva',  '(11) 98888-1111', 'Sem chocolate'),
  (:'uid', 'João Pereira', '(11) 97777-2222', 'Prefere recheio de ninho'),
  (:'uid', 'Ana Costa',    '(11) 96666-3333', 'Cliente do bairro, entrega sempre à tarde')
on conflict do nothing;

-- Orçamentos de exemplo (datas espalhadas no mês corrente)
insert into public.quotes
  (user_id, customer_name, customer_phone, product, size, flavor, filling, decoration, message,
   delivery_date, delivery_time, value, status, store_name)
values
  (:'uid', 'Maria Silva',  '(11) 98888-1111', 'bolo', '2 kg', 'chocolate', 'brigadeiro', 'Tema infantil',
   'Parabéns, Ana!', current_date + 2, '15:00', 189.90, 'pending', 'Padaria Pão Quentinho'),
  (:'uid', 'João Pereira', '(11) 97777-2222', 'doces', '50 unidades', 'variado', 'ninho', '',
   '', current_date + 4, '10:30', 145.00, 'paid', 'Padaria Pão Quentinho'),
  (:'uid', 'Ana Costa',    '(11) 96666-3333', 'torta', '24 cm', 'morango', 'creme', 'Flores',
   '', current_date - 3, '16:00', 132.50, 'delivered', 'Padaria Pão Quentinho');

-- Histórico de pagamento de exemplo
insert into public.payments (user_id, amount, currency, status, provider, plan_id, billing_cycle, paid_at)
values
  (:'uid', 29.90, 'BRL', 'paid', 'manual', 'complete', 'monthly', now() - interval '35 days'),
  (:'uid', 29.90, 'BRL', 'paid', 'manual', 'complete', 'monthly', now() - interval '5 days')
on conflict do nothing;
