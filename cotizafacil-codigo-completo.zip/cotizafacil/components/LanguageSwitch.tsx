'use client';

import { useApp } from './AppProvider';
import { LOCALES } from '@/lib/i18n';

/** Troca de idioma em 1 clique (🇧🇷 PT / 🇪🇸 ES). */
export default function LanguageSwitch({ compact = false }: { compact?: boolean }) {
  const { locale, setLocale, t } = useApp();
  return (
    <div className="lang-switch" role="group" aria-label={t('lang.switch')}>
      {LOCALES.map((l) => (
        <button
          key={l.id}
          type="button"
          aria-pressed={locale === l.id}
          onClick={() => setLocale(l.id)}
          title={l.label}
        >
          {l.flag}
          {!compact && <span style={{ marginLeft: 5 }}>{l.id.toUpperCase()}</span>}
        </button>
      ))}
    </div>
  );
}
