'use client';

import { useMemo, useState } from 'react';
import { useApp } from './AppProvider';
import { formatLongDate } from '@/lib/i18n';
import { formatBRL } from '@/lib/plans';
import type { Quote } from '@/lib/types';

function ymd(d: Date) {
  const m = `${d.getMonth() + 1}`.padStart(2, '0');
  const day = `${d.getDate()}`.padStart(2, '0');
  return `${d.getFullYear()}-${m}-${day}`;
}

/** Calendário mensal com marcação dos dias que têm entrega. */
export default function Calendar({ quotes }: { quotes: Quote[] }) {
  const { locale, t } = useApp();
  const today = new Date();
  const [cursor, setCursor] = useState(new Date(today.getFullYear(), today.getMonth(), 1));
  const [selected, setSelected] = useState<string | null>(ymd(today));

  const byDay = useMemo(() => {
    const map: Record<string, Quote[]> = {};
    quotes.forEach((q) => {
      if (!q.delivery_date) return;
      const key = String(q.delivery_date).slice(0, 10);
      (map[key] ||= []).push(q);
    });
    return map;
  }, [quotes]);

  const days = useMemo(() => {
    const first = new Date(cursor.getFullYear(), cursor.getMonth(), 1);
    const last = new Date(cursor.getFullYear(), cursor.getMonth() + 1, 0);
    const cells: (Date | null)[] = [];
    const startPad = (first.getDay() + 6) % 7; // segunda como primeiro dia
    for (let i = 0; i < startPad; i += 1) cells.push(null);
    for (let d = 1; d <= last.getDate(); d += 1) cells.push(new Date(cursor.getFullYear(), cursor.getMonth(), d));
    while (cells.length % 7 !== 0) cells.push(null);
    return cells;
  }, [cursor]);

  const monthLabel = cursor.toLocaleDateString(locale === 'es' ? 'es-ES' : 'pt-BR', {
    month: 'long',
    year: 'numeric',
  });

  const weekdays =
    locale === 'es' ? ['L', 'M', 'M', 'J', 'V', 'S', 'D'] : ['S', 'T', 'Q', 'Q', 'S', 'S', 'D'];

  const dayQuotes = selected ? byDay[selected] || [] : [];

  return (
    <div className="card">
      <div className="row-between" style={{ marginBottom: 10 }}>
        <button className="btn btn-ghost btn-sm" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() - 1, 1))}>
          ←
        </button>
        <strong style={{ textTransform: 'capitalize' }}>{monthLabel}</strong>
        <button className="btn btn-ghost btn-sm" onClick={() => setCursor(new Date(cursor.getFullYear(), cursor.getMonth() + 1, 1))}>
          →
        </button>
      </div>

      <div className="cal-grid">
        {weekdays.map((w, i) => (
          <div className="cal-head" key={`${w}-${i}`}>
            {w}
          </div>
        ))}
        {days.map((d, i) => {
          if (!d) return <div className="cal-day empty" key={`e-${i}`} />;
          const key = ymd(d);
          const has = !!byDay[key]?.length;
          const cls = ['cal-day'];
          if (key === ymd(today)) cls.push('today');
          if (key === selected) cls.push('selected');
          return (
            <button key={key} className={cls.join(' ')} onClick={() => setSelected(key)}>
              <span>{d.getDate()}</span>
              {has && <span className="cal-dot" />}
            </button>
          );
        })}
      </div>

      <div style={{ marginTop: 16 }}>
        <div className="row" style={{ justifyContent: 'space-between' }}>
          <strong>{selected ? formatLongDate(selected, locale) : t('history.ordersOn')}</strong>
          <span className="badge badge-info">{dayQuotes.length}</span>
        </div>
        {dayQuotes.length === 0 ? (
          <p className="muted small" style={{ marginTop: 8 }}>{t('history.noOrdersDay')}</p>
        ) : (
          dayQuotes.map((q) => (
            <div className="list-item" key={q.id}>
              <div className="list-main">
                <div className="list-title">{q.customer_name}</div>
                <div className="list-sub">
                  {t(`quote.${q.product}`)}
                  {q.delivery_time ? ` · ${q.delivery_time}` : ''}
                </div>
              </div>
              <div style={{ textAlign: 'right' }}>
                <div className="list-value">{formatBRL(q.value)}</div>
                <span
                  className={`badge ${q.status === 'paid' ? 'badge-paid' : q.status === 'delivered' ? 'badge-delivered' : 'badge-pending'}`}
                >
                  {t(`status.${q.status}`)}
                </span>
              </div>
            </div>
          ))
        )}
      </div>
    </div>
  );
}
