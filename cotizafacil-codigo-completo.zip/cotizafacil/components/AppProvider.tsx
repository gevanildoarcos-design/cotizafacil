'use client';

import { createContext, useCallback, useContext, useEffect, useMemo, useState } from 'react';
import { createT } from '@/lib/i18n';
import { auth, profiles, quotes, type AuthUser, type Quota } from '@/lib/repo';
import { isSupabaseConfigured } from '@/lib/supabase/client';
import type { Locale, Profile } from '@/lib/types';

interface Toast {
  id: string;
  msg: string;
  kind: 'ok' | 'warn' | 'info';
}

interface Ctx {
  locale: Locale;
  setLocale: (l: Locale) => void;
  t: (k: string, vars?: Record<string, string | number>) => string;
  user: AuthUser | null;
  profile: Profile | null;
  quota: Quota | null;
  loading: boolean;
  isDemo: boolean;
  refresh: () => Promise<void>;
  setProfile: (p: Profile) => void;
  refreshQuota: () => Promise<void>;
  signOut: () => Promise<void>;
  toast: (msg: string, kind?: Toast['kind']) => void;
}

const AppCtx = createContext<Ctx | null>(null);

const LOCALE_KEY = 'cf.locale';

export function AppProvider({ children }: { children: React.ReactNode }) {
  const [locale, setLocaleState] = useState<Locale>('pt');
  const [user, setUser] = useState<AuthUser | null>(null);
  const [profile, setProfileState] = useState<Profile | null>(null);
  const [quota, setQuota] = useState<Quota | null>(null);
  const [loading, setLoading] = useState(true);
  const [toasts, setToasts] = useState<Toast[]>([]);

  const toast = useCallback((msg: string, kind: Toast['kind'] = 'ok') => {
    const id = Math.random().toString(36).slice(2);
    setToasts((prev) => [...prev, { id, msg, kind }]);
    setTimeout(() => setToasts((prev) => prev.filter((x) => x.id !== id)), 3600);
  }, []);

  const refreshQuota = useCallback(async () => {
    setUser((u) => {
      const current = u;
      if (current) {
        quotes
          .quota(
            { ...(profile as Profile), id: current.id } as Profile,
            current.id,
          )
          .then(setQuota)
          .catch(() => {});
      }
      return u;
    });
  }, [profile]);

  const refresh = useCallback(async () => {
    setLoading(true);
    try {
      const u = await auth.getUser();
      setUser(u);
      if (u) {
        const p = await profiles.get(u, (typeof localStorage !== 'undefined'
          ? (localStorage.getItem(LOCALE_KEY) as Locale)
          : 'pt') || 'pt');
        setProfileState(p);
        if (p?.language) setLocaleState(p.language);
        const q = await quotes.quota(p, u.id);
        setQuota(q);
      } else {
        setProfileState(null);
        setQuota(null);
      }
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    const stored = (typeof localStorage !== 'undefined' ? localStorage.getItem(LOCALE_KEY) : null) as Locale | null;
    if (stored === 'pt' || stored === 'es') setLocaleState(stored);
    else if (typeof navigator !== 'undefined' && /^es/i.test(navigator.language)) setLocaleState('es');
    void refresh();
  }, [refresh]);

  const setLocale = useCallback(
    (l: Locale) => {
      setLocaleState(l);
      try {
        localStorage.setItem(LOCALE_KEY, l);
        document.documentElement.lang = l === 'es' ? 'es' : 'pt-BR';
      } catch {
        /* ignore */
      }
      if (profile) void profiles.update({ language: l }).then((p) => setProfileState(p)).catch(() => {});
    },
    [profile],
  );

  const setProfile = useCallback((p: Profile) => setProfileState(p), []);

  const signOut = useCallback(async () => {
    await auth.signOut();
    setUser(null);
    setProfileState(null);
    setQuota(null);
    window.location.href = '/';
  }, []);

  const t = useMemo(() => createT(locale), [locale]);

  const value: Ctx = {
    locale,
    setLocale,
    t,
    user,
    profile,
    quota,
    loading,
    isDemo: !isSupabaseConfigured(),
    refresh,
    setProfile,
    refreshQuota,
    signOut,
    toast,
  };

  return (
    <AppCtx.Provider value={value}>
      {children}
      <div style={{ position: 'fixed', left: 12, right: 12, bottom: 84, zIndex: 90, display: 'grid', gap: 8, pointerEvents: 'none' }}>
        {toasts.map((x) => (
          <div
            key={x.id}
            className={`alert ${x.kind === 'warn' ? 'alert-warn' : x.kind === 'info' ? 'alert-info' : 'alert-ok'}`}
            style={{ margin: 0, boxShadow: 'var(--sombra)', maxWidth: 480, marginInline: 'auto', width: '100%' }}
          >
            {x.msg}
          </div>
        ))}
      </div>
    </AppCtx.Provider>
  );
}

export function useApp(): Ctx {
  const ctx = useContext(AppCtx);
  if (!ctx) throw new Error('useApp precisa estar dentro de <AppProvider>');
  return ctx;
}
