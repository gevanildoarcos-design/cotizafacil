'use client';

import { useState } from 'react';
import { useApp } from './AppProvider';
import { PLANS, annualSavings, formatBRL, priceFor, type BillingCycle, type PlanId } from '@/lib/plans';

export default function PlanCards({
  onSelect,
  currentPlan,
  busyPlan,
  ctaLogin = false,
}: {
  onSelect: (plan: PlanId, cycle: BillingCycle) => void;
  currentPlan?: PlanId;
  busyPlan?: string | null;
  ctaLogin?: boolean;
}) {
  const { t } = useApp();
  const [cycle, setCycle] = useState<BillingCycle>('monthly');

  return (
    <>
      <div className="center section">
        <div className="lang-switch" style={{ display: 'inline-flex' }}>
          <button type="button" aria-pressed={cycle === 'monthly'} onClick={() => setCycle('monthly')}>
            {t('plans.monthly')}
          </button>
          <button type="button" aria-pressed={cycle === 'annual'} onClick={() => setCycle('annual')}>
            {t('plans.annual')}
          </button>
        </div>
        <p className="small muted" style={{ marginTop: 8 }}>
          🎁 {t('plans.annualBadge')}
        </p>
      </div>

      <div className="grid grid-4">
        {PLANS.map((plan) => {
          const isCurrent = currentPlan === plan.id;
          const price = priceFor(plan, cycle);
          const saving = plan.monthly > 0 ? annualSavings(plan) : 0;
          return (
            <div key={plan.id} className={`card plan-card${plan.highlight ? ' highlight' : ''}`}>
              {plan.highlight && <span className="ribbon">Popular</span>}
              <div style={{ fontSize: 28 }}>{plan.emoji}</div>
              <h3 style={{ margin: '6px 0 2px' }}>{t(plan.i18nName)}</h3>
              <div className="plan-price">
                {price === 0 ? t('plans.free.name') : formatBRL(price)}
                {price > 0 && <small>{cycle === 'annual' ? t('plans.perYear') : t('plans.perMonth')}</small>}
              </div>
              {cycle === 'annual' && saving > 0 && (
                <div className="tiny" style={{ color: 'var(--verde)', fontWeight: 800 }}>
                  {t('plans.saveAnnual')} {formatBRL(saving)}
                </div>
              )}
              <div className="tiny muted" style={{ marginTop: 4 }}>
                {plan.users} {plan.users > 1 ? t('plans.users') : t('plans.user')}
              </div>

              <ul className="plan-features">
                {plan.i18nFeatureKeys.map((k) => (
                  <li key={k}>{t(k)}</li>
                ))}
              </ul>

              {isCurrent ? (
                <button className="btn btn-ghost btn-block" disabled>
                  ✓ {t('plans.current')}
                </button>
              ) : (
                <button
                  className={`btn ${plan.highlight ? 'btn-primary' : 'btn-brown'} btn-block`}
                  onClick={() => onSelect(plan.id, cycle)}
                  disabled={busyPlan === plan.id || (plan.id === 'free' && ctaLogin)}
                >
                  {busyPlan === plan.id ? <span className="spinner" /> : null}
                  {plan.id === 'free' ? t('plans.continueFree') : ctaLogin ? t('plans.loginToSubscribe') : t('plans.choose')}
                </button>
              )}
            </div>
          );
        })}
      </div>
    </>
  );
}
