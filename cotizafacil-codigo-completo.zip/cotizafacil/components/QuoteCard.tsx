'use client';

import { useState } from 'react';
import { useApp } from './AppProvider';
import { formatDate } from '@/lib/i18n';
import type { Quote } from '@/lib/types';
import { PLANS, formatBRL } from '@/lib/plans';

/** Cartão de orçamento com ações: PDF, WhatsApp, pago, editado e excluído. */
export default function QuoteCard({ quote, onChanged }: { quote: Quote; onChanged?: () => void }) {
  const { t, locale, profile, toast } = useApp();
  const [busy, setBusy] = useState(false);

  const statusClass =
    quote.status === 'paid' ? 'badge-paid' : quote.status === 'delivered' ? 'badge-delivered' : 'badge-pending';

  async function sendWhatsapp() {
    const { buildWhatsappLink } = await import('@/lib/whatsapp');
    const url = buildWhatsappLink(quote, {
      language: locale,
      storeName: profile?.store_name || quote.store_name,
    });
    window.open(url, '_blank', 'noopener');
  }

  async function downloadPdf() {
    setBusy(true);
    try {
      const { generateQuotePdf } = await import('@/lib/pdf');
      await generateQuotePdf({
        quote,
        locale,
        storeName: profile?.store_name,
        storePhone: profile?.store_phone,
        logoDataUrl: profile?.store_logo || null,
      });
    } finally {
      setBusy(false);
    }
  }

  async function setStatus(status: Quote['status']) {
    setBusy(true);
    try {
      const { quotes } = await import('@/lib/repo');
      await quotes.update(quote.id, { status });
      onChanged?.();
    } catch (e: any) {
      toast(e?.message || 'Erro', 'warn');
    } finally {
      setBusy(false);
    }
  }

  async function remove() {
    if (!confirm(t('history.confirmDelete'))) return;
    const { quotes } = await import('@/lib/repo');
    await quotes.remove(quote.id);
    onChanged?.();
  }

  return (
    <div className="card card-tight">
      <div className="row-between" style={{ alignItems: 'flex-start' }}>
        <div className="list-main">
          <div className="list-title">
            {t(`quote.${quote.product}`)} · {quote.customer_name}
          </div>
          <div className="list-sub">
            {[quote.size, quote.flavor].filter(Boolean).join(' · ') || '—'}
            {quote.delivery_date && (
              <>
                {' · 🚚 '}
                {formatDate(quote.delivery_date, locale)}
                {quote.delivery_time ? ` ${quote.delivery_time}` : ''}
              </>
            )}
          </div>
        </div>
        <div className="center">
          <div className="list-value">{formatBRL(quote.value)}</div>
          <span className={`badge ${statusClass}`}>{t(`status.${quote.status}`)}</span>
        </div>
      </div>

      <div className="actions">
        <button className="btn btn-ghost btn-sm" onClick={downloadPdf} disabled={busy}>
          📄 {t('quote.generatePdf')}
        </button>
        <button className="btn btn-whats btn-sm" onClick={sendWhatsapp} disabled={busy}>
          📲 {t('history.resend')}
        </button>
        {quote.status !== 'paid' && (
          <button className="btn btn-ghost btn-sm" onClick={() => setStatus('paid')} disabled={busy}>
            ✅ {t('history.markPaid')}
          </button>
        )}
        {quote.status !== 'delivered' && (
          <button className="btn btn-ghost btn-sm" onClick={() => setStatus('delivered')} disabled={busy}>
            📦 {t('history.markDelivered')}
          </button>
        )}
        <a className="btn btn-ghost btn-sm" href={`/novo?id=${quote.id}`}>
          ✏️ {t('history.edit')}
        </a>
        <button className="btn btn-danger btn-sm" onClick={remove} disabled={busy}>
          🗑️ {t('history.delete')}
        </button>
      </div>
    </div>
  );
}
