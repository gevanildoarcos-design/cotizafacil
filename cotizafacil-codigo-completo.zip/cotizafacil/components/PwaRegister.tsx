'use client';

import { useEffect } from 'react';
import { useApp } from './AppProvider';

/**
 * Registra o service worker (atalho na tela inicial / funcionamento offline parcial).
 * PWA: manifest.json + sw.js em /public.
 */
export default function PwaRegister() {
  const { t } = useApp();

  useEffect(() => {
    if (typeof window === 'undefined' || !('serviceWorker' in navigator)) return;
    const onLoad = () => {
      navigator.serviceWorker.register('/sw.js').catch(() => {});
    };
    if (document.readyState === 'complete') onLoad();
    else window.addEventListener('load', onLoad);
    return () => window.removeEventListener('load', onLoad);
  }, []);

  return (
    <div className="card small" style={{ background: 'var(--amarelo-claro)', border: 0 }}>
      📱 <strong>{t('settings.installApp')}</strong>
      <div className="tiny" style={{ marginTop: 4 }}>{t('settings.installHint')}</div>
    </div>
  );
}
