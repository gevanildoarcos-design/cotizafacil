'use client';

import Link from 'next/link';
import { usePathname, useRouter } from 'next/navigation';
import { useEffect } from 'react';
import { useApp } from './AppProvider';
import LanguageSwitch from './LanguageSwitch';

const NAV = [
  { href: '/painel', ico: '🏠', key: 'nav.home' },
  { href: '/novo', ico: '➕', key: 'nav.new' },
  { href: '/historico', ico: '📅', key: 'nav.history' },
  { href: '/clientes', ico: '👥', key: 'nav.clients' },
  { href: '/assinatura', ico: '⭐', key: 'nav.subscription' },
];

export default function AppShell({
  title,
  subtitle,
  requireAuth = false,
  children,
  action,
}: {
  title?: string;
  subtitle?: string;
  requireAuth?: boolean;
  children: React.ReactNode;
  action?: React.ReactNode;
}) {
  const { t, user, loading, signOut, profile, quota } = useApp();
  const path = usePathname();
  const router = useRouter();

  useEffect(() => {
    if (!loading && requireAuth && !user) router.replace('/entrar');
  }, [loading, user, requireAuth, router]);

  const showGate = requireAuth && (loading || !user);

  return (
    <>
      <header className="topbar no-print">
        <div className="wrap topbar-inner">
          <Link href={user ? '/painel' : '/'} className="brand" style={{ textDecoration: 'none' }}>
            <span className="brand-mark">🧁</span>
            <span>{t('app.name')}</span>
          </Link>

          <nav className="desktop-nav">
            {user &&
              NAV.map((n) => (
                <Link key={n.href} href={n.href} className={path === n.href ? 'active' : ''}>
                  {t(n.key)}
                </Link>
              ))}
          </nav>

          <div className="row" style={{ gap: 8 }}>
            <LanguageSwitch />
            {user ? (
              <>
                <Link href="/configuracoes" className="btn btn-ghost btn-sm" title={t('nav.settings')}>
                  ⚙️
                </Link>
                <button className="btn btn-ghost btn-sm" onClick={signOut}>
                  {t('nav.logout')}
                </button>
              </>
            ) : (
              <>
                <Link href="/entrar" className="btn btn-ghost btn-sm">
                  {t('landing.login')}
                </Link>
                <Link href="/entrar?tab=signup" className="btn btn-primary btn-sm">
                  {t('landing.startFree')}
                </Link>
              </>
            )}
          </div>
        </div>
      </header>

      <main className="page">
        <div className="wrap">
          {showGate ? (
            <div className="center" style={{ padding: 60 }}>
              <div className="spinner" style={{ margin: '0 auto' }} />
            </div>
          ) : (
            <>
              {title && (
                <div className="row-between section" style={{ marginBottom: 6 }}>
                  <div>
                    <h1 style={{ marginBottom: 2 }}>{title}</h1>
                    {subtitle && <p className="muted" style={{ marginBottom: 0 }}>{subtitle}</p>}
                  </div>
                  {action}
                </div>
              )}

              {user && quota && quota.limit !== null && (
                <div className={`alert ${quota.reached ? 'alert-warn' : 'alert-info'} small`}>
                  {quota.used} {t('common.of')} {quota.limit} {t('quote.quotaUsed')}
                  {quota.reached && (
                    <>
                      {' — '}
                      <Link href="/planos" style={{ fontWeight: 800, textDecoration: 'underline' }}>
                        {t('quote.limitReachedCta')}
                      </Link>
                    </>
                  )}
                </div>
              )}

              {user && profile?.is_demo && (
                <div className="alert alert-info small">🧪 {t('common.demoBanner')}</div>
              )}

              {children}
            </>
          )}
        </div>
      </main>

      {user && (
        <nav className="bottomnav no-print">
          {NAV.map((n) => (
            <Link key={n.href} href={n.href} className={path === n.href ? 'active' : ''}>
              <span className="ico">{n.ico}</span>
              <span>{t(n.key)}</span>
            </Link>
          ))}
        </nav>
      )}
    </>
  );
}
