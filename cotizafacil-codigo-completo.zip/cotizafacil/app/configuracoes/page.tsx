'use client';

import { useState } from 'react';
import AppShell from '@/components/AppShell';
import PwaRegister from '@/components/PwaRegister';
import LanguageSwitch from '@/components/LanguageSwitch';
import { useApp } from '@/components/AppProvider';
import { profiles } from '@/lib/repo';
import { LOCALES } from '@/lib/i18n';

export default function ConfiguracoesPage() {
  const { t, locale, user, profile, setProfile, signOut, toast, isDemo } = useApp();
  const [storeName, setStoreName] = useState(profile?.store_name || '');
  const [storePhone, setStorePhone] = useState(profile?.store_phone || '');
  const [logo, setLogo] = useState<string>(profile?.store_logo || '');
  const [busy, setBusy] = useState(false);

  async function save() {
    setBusy(true);
    try {
      const patch = await profiles.update({ store_name: storeName, store_phone: storePhone, store_logo: logo });
      setProfile(patch);
      toast(t('settings.saved') + ' ✓');
    } catch (e: any) {
      toast(e?.message || 'Erro', 'warn');
    } finally {
      setBusy(false);
    }
  }

  function onLogo(file?: File | null) {
    if (!file) return;
    if (file.size > 300 * 1024) {
      toast(t('settings.logoHint'), 'warn');
      return;
    }
    const reader = new FileReader();
    reader.onload = () => setLogo(String(reader.result));
    reader.readAsDataURL(file);
  }

  return (
    <AppShell title={t('settings.title')} requireAuth>
      <div className="grid grid-2">
        <div className="card">
          <h3>🏪 {t('settings.account')}</h3>

          <label className="field">
            <span className="label">{t('settings.storeName')}</span>
            <input className="input" value={storeName} onChange={(e) => setStoreName(e.target.value)} placeholder="Padaria do Bairro" />
          </label>

          <label className="field">
            <span className="label">{t('settings.storePhone')}</span>
            <input
              className="input"
              value={storePhone}
              onChange={(e) => setStorePhone(e.target.value)}
              placeholder="(11) 3333-4444"
              inputMode="tel"
            />
          </label>

          <div className="field">
            <span className="label">{t('settings.logo')}</span>
            <div className="row">
              {logo ? (
                // eslint-disable-next-line @next/next/no-img-element
                <img src={logo} alt="logo" style={{ width: 64, height: 64, borderRadius: 12, objectFit: 'cover', border: '1px solid var(--borda)' }} />
              ) : (
                <div className="brand-mark" style={{ width: 64, height: 64, fontSize: 28 }}>🧁</div>
              )}
              <label className="btn btn-ghost btn-sm" style={{ cursor: 'pointer' }}>
                📷 {t('settings.uploadLogo')}
                <input type="file" accept="image/png,image/jpeg" hidden onChange={(e) => onLogo(e.target.files?.[0])} />
              </label>
              {logo && (
                <button className="btn btn-ghost btn-sm" onClick={() => setLogo('')} type="button">
                  🗑️ {t('settings.removeLogo')}
                </button>
              )}
            </div>
            <span className="hint">{t('settings.logoHint')}</span>
          </div>

          <div className="field">
            <span className="label">{t('settings.language')}</span>
            <LanguageSwitch />
            <span className="hint">{LOCALES.map((l) => `${l.flag} ${l.label}`).join(' · ')}</span>
          </div>

          <button className="btn btn-primary btn-block" onClick={save} disabled={busy || isDemo}>
            💾 {t('common.save')}
          </button>
          {isDemo && <p className="tiny muted center" style={{ marginTop: 8 }}>{t('common.demoBanner')}</p>}
        </div>

        <div>
          <div className="card">
            <h3>👤 {t('settings.account')}</h3>
            <div className="list-item">
              <span className="list-sub">{t('auth.email')}</span>
              <strong>{user?.email || '—'}</strong>
            </div>
            <div className="list-item">
              <span className="list-sub">{t('plans.title')}</span>
              <strong>{profile?.plan || 'free'}</strong>
            </div>
            <div className="actions" style={{ marginTop: 12 }}>
              <button className="btn btn-ghost btn-sm" onClick={signOut}>
                {t('common.logout')}
              </button>
            </div>
          </div>

          <div className="card section">
            <h3>🔔 {t('settings.notifications')}</h3>
            <p className="small muted" style={{ marginBottom: 0 }}>{t('settings.notificationsHint')}</p>
          </div>

          <div className="section">
            <PwaRegister />
          </div>

          <div className="card section" style={{ borderColor: '#F5C6C0' }}>
            <h3 style={{ color: 'var(--vermelho)' }}>{t('settings.dangerZone')}</h3>
            <button
              className="btn btn-danger btn-sm"
              onClick={async () => {
                if (!confirm(t('sub.cancelConfirm'))) return;
                await signOut();
              }}
            >
              {t('settings.deleteAccount')}
            </button>
          </div>
        </div>
      </div>
    </AppShell>
  );
}
