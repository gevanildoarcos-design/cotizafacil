'use client';

import { useEffect, useMemo, useState } from 'react';
import AppShell from '@/components/AppShell';
import { useApp } from '@/components/AppProvider';
import { clients as repo, quotes } from '@/lib/repo';
import { formatBRL } from '@/lib/plans';
import { formatDate } from '@/lib/i18n';
import type { Client, Quote } from '@/lib/types';

const blank = { name: '', phone: '', notes: '' };

export default function ClientesPage() {
  const { t, locale, user, toast } = useApp();
  const [list, setList] = useState<Client[]>([]);
  const [allQuotes, setAllQuotes] = useState<Quote[]>([]);
  const [form, setForm] = useState<{ id?: string; name: string; phone: string; notes: string }>({ ...blank });
  const [open, setOpen] = useState(false);
  const [q, setQ] = useState('');
  const [loading, setLoading] = useState(true);

  async function load() {
    if (!user) return;
    setLoading(true);
    try {
      const [c, qs] = await Promise.all([repo.list(user.id), quotes.list(user.id)]);
      setList(c);
      setAllQuotes(qs);
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const stats = useMemo(() => {
    const digits = (p: string) => (p || '').replace(/\D/g, '');
    const map = new Map<string, { count: number; total: number; last?: string }>();
    allQuotes.forEach((quote) => {
      const key = digits(quote.customer_phone) || quote.customer_name.toLowerCase();
      const cur = map.get(key) || { count: 0, total: 0, last: undefined };
      cur.count += 1;
      cur.total += Number(quote.value || 0);
      if (!cur.last || String(quote.created_at) > cur.last) cur.last = quote.created_at;
      map.set(key, cur);
    });
    return map;
  }, [allQuotes]);

  const filtered = useMemo(() => {
    const s = q.trim().toLowerCase();
    if (!s) return list;
    return list.filter(
      (c) => c.name.toLowerCase().includes(s) || (c.phone || '').includes(s) || (c.notes || '').toLowerCase().includes(s),
    );
  }, [list, q]);

  async function save() {
    if (!user || !form.name) return;
    try {
      await repo.save({ id: form.id, name: form.name, phone: form.phone, notes: form.notes }, user.id);
      setForm({ ...blank });
      setOpen(false);
      await load();
      toast(t('clients.saved') + ' ✓');
    } catch (e: any) {
      toast(e?.message || 'Erro', 'warn');
    }
  }

  async function remove(c: Client) {
    if (!confirm(t('clients.confirmDelete'))) return;
    await repo.remove(c.id);
    await load();
  }

  return (
    <AppShell
      title={t('clients.title')}
      subtitle={t('clients.sub')}
      requireAuth
      action={
        <button
          className="btn btn-primary"
          onClick={() => {
            setForm({ ...blank });
            setOpen(true);
          }}
        >
          ➕ {t('clients.new')}
        </button>
      }
    >
      <label className="field">
        <input
          className="input"
          placeholder={`🔍 ${t('clients.search')}`}
          value={q}
          onChange={(e) => setQ(e.target.value)}
        />
      </label>

      {open && (
        <div className="card section">
          <h3>{form.id ? t('clients.edit') : t('clients.new')}</h3>
          <label className="field">
            <span className="label">{t('clients.name')}</span>
            <input
              className="input"
              value={form.name}
              onChange={(e) => setForm({ ...form, name: e.target.value })}
              placeholder="Maria"
            />
          </label>
          <label className="field">
            <span className="label">{t('clients.phone')}</span>
            <input
              className="input"
              value={form.phone}
              onChange={(e) => setForm({ ...form, phone: e.target.value })}
              placeholder={t('quote.phonePh')}
              inputMode="tel"
            />
          </label>
          <label className="field">
            <span className="label">{t('clients.notes')}</span>
            <input
              className="input"
              value={form.notes}
              onChange={(e) => setForm({ ...form, notes: e.target.value })}
              placeholder={t('clients.notesPh')}
            />
          </label>
          <div className="row">
            <button className="btn btn-brown" onClick={save}>
              💾 {t('clients.save')}
            </button>
            <button className="btn btn-ghost" onClick={() => setOpen(false)}>
              {t('common.cancel')}
            </button>
          </div>
        </div>
      )}

      {loading ? (
        <div className="center" style={{ padding: 40 }}>
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : filtered.length === 0 ? (
        <div className="card center">
          <p className="muted">{t('clients.empty')}</p>
        </div>
      ) : (
        <div className="grid grid-2">
          {filtered.map((c) => {
            const key = (c.phone || '').replace(/\D/g, '') || c.name.toLowerCase();
            const st = stats.get(key);
            const history = allQuotes.filter((x) => (x.customer_phone || '').replace(/\D/g, '') === (c.phone || '').replace(/\D/g, ''));
            return (
              <div className="card" key={c.id}>
                <div className="row-between">
                  <div className="list-main">
                    <div className="list-title">{c.name}</div>
                    <div className="list-sub">{c.phone || '—'}</div>
                  </div>
                  <span className="badge badge-info">
                    {st?.count || 0} {t('clients.orders')}
                  </span>
                </div>

                {c.notes && <p className="small" style={{ marginTop: 8 }}>📝 {c.notes}</p>}

                <div className="row-between small" style={{ marginTop: 8 }}>
                  <span className="muted">
                    {t('clients.lastOrder')}: {formatDate(st?.last, locale) || '—'}
                  </span>
                  <strong>{formatBRL(st?.total || 0)}</strong>
                </div>

                {history.length > 0 && (
                  <details style={{ marginTop: 8 }}>
                    <summary className="small" style={{ cursor: 'pointer', fontWeight: 700, color: 'var(--marrom)' }}>
                      {t('nav.history')} ({history.length})
                    </summary>
                    {history.slice(0, 6).map((h) => (
                      <div className="list-item" key={h.id}>
                        <div className="list-main">
                          <div className="list-sub">
                            {t(`quote.${h.product}`)} · {formatDate(h.created_at, locale)}
                          </div>
                        </div>
                        <span className="list-value">{formatBRL(h.value)}</span>
                      </div>
                    ))}
                  </details>
                )}

                <div className="actions">
                  <button
                    className="btn btn-ghost btn-sm"
                    onClick={() => {
                      setForm({ id: c.id, name: c.name, phone: c.phone, notes: c.notes || '' });
                      setOpen(true);
                    }}
                  >
                    ✏️ {t('clients.edit')}
                  </button>
                  <button className="btn btn-danger btn-sm" onClick={() => remove(c)}>
                    🗑️ {t('clients.delete')}
                  </button>
                </div>
              </div>
            );
          })}
        </div>
      )}
    </AppShell>
  );
}
