import { NextResponse } from 'next/server';
import { getServiceSupabase } from '@/lib/supabase/server';
import { sendReminderEmail } from '@/lib/email';
import { getPlan } from '@/lib/plans';
import { paymentConfig } from '@/config/payment.config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * GET /api/cron/lembretes
 * Agendado em vercel.json (todos os dias às 12:00 UTC).
 * Envia e-mail 3 dias antes do vencimento da assinatura e marca reminder_sent_at,
 * evitando e-mails repetidos. A Vercel envia Authorization: Bearer $CRON_SECRET.
 *
 * Teste local:  curl -H "Authorization: Bearer $CRON_SECRET" http://localhost:3000/api/cron/lembretes
 */
export async function GET(req: Request) {
  const secret = process.env.CRON_SECRET;
  if (secret) {
    const auth = req.headers.get('authorization') || '';
    if (auth !== `Bearer ${secret}`) {
      return NextResponse.json({ error: 'não autorizado' }, { status: 401 });
    }
  }

  const supabase = getServiceSupabase();
  if (!supabase) {
    return NextResponse.json({ ok: true, sent: 0, note: 'Supabase não configurado' });
  }

  const { data: due, error } = await supabase
    .from('subscriptions_due_in_3_days')
    .select('id, name, email, language, plan, billing_cycle, next_charge_at, store_name');

  if (error) return NextResponse.json({ ok: false, error: error.message }, { status: 500 });

  const results: { email: string; ok: boolean; error?: string }[] = [];

  for (const row of due || []) {
    const plan = getPlan(row.plan);
    const res = await sendReminderEmail({
      to: row.email,
      name: row.name || row.store_name || '',
      locale: row.language === 'es' ? 'es' : 'pt',
      planName: plan.id,
      cycle: row.billing_cycle === 'annual' ? 'annual' : 'monthly',
      nextChargeAt: row.next_charge_at,
      currency: paymentConfig.currency,
    });
    results.push({ email: row.email, ...res });

    if (res.ok) {
      await supabase
        .from('profiles')
        .update({ reminder_sent_at: new Date().toISOString() })
        .eq('id', row.id);
    }
  }

  return NextResponse.json({ ok: true, checked: (due || []).length, sent: results.filter((r) => r.ok).length, results });
}
