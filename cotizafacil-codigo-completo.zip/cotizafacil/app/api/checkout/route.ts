import { NextResponse } from 'next/server';
import { getServiceSupabase } from '@/lib/supabase/server';
import { paymentConfig, isPaymentGatewayConfigured } from '@/config/payment.config';
import { getPlan, priceFor, planReference, type BillingCycle, type PlanId } from '@/lib/plans';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

interface Body {
  plan: PlanId;
  cycle: BillingCycle;
  locale?: 'pt' | 'es';
}

/**
 * POST /api/checkout
 * Cria a assinatura no gateway ativo e devolve a URL de pagamento.
 * Sem gateway configurado devolve { mode: 'demo' } para o app simular (só para testes).
 */
export async function POST(req: Request) {
  let body: Body;
  try {
    body = (await req.json()) as Body;
  } catch {
    return NextResponse.json({ error: 'JSON inválido' }, { status: 400 });
  }

  const plan = getPlan(body.plan);
  const cycle: BillingCycle = body.cycle === 'annual' ? 'annual' : 'monthly';
  if (plan.id === 'free') return NextResponse.json({ error: 'Plano gratuito não precisa de checkout' }, { status: 400 });

  const amount = priceFor(plan, cycle);
  const origin = process.env.NEXT_PUBLIC_APP_URL || new URL(req.url).origin;

  // ---------- quem está comprando ----------
  const supabase = getServiceSupabase();
  let userId = 'demo-user';
  let email = 'demo@cotizafacil.app';
  let storeName = 'Padaria';

  if (supabase) {
    const auth = req.headers.get('authorization') || '';
    const token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
    if (token) {
      const { data } = await supabase.auth.getUser(token);
      if (data?.user) {
        userId = data.user.id;
        email = data.user.email || email;
      }
    }
    if (userId !== 'demo-user') {
      const { data: prof } = await supabase.from('profiles').select('store_name').eq('id', userId).maybeSingle();
      storeName = prof?.store_name || storeName;
    }
  }

  if (!isPaymentGatewayConfigured()) {
    return NextResponse.json({ mode: 'demo', provider: paymentConfig.provider, amount, currency: paymentConfig.currency });
  }

  // ======================= STRIPE =========================
  if (paymentConfig.provider === 'stripe') {
    try {
      const Stripe = (await import('stripe')).default;
      const stripe = new Stripe(paymentConfig.credentials.stripeSecretKey);
      const priceId =
        cycle === 'annual'
          ? process.env[plan.stripePriceEnvAnnual || '']
          : process.env[plan.stripePriceEnvMonthly || ''];

      const session = await stripe.checkout.sessions.create({
        mode: 'subscription',
        // se o preço não estiver configurado, cria o preço inline (assinatura mensal/anual)
        line_items: priceId
          ? [{ price: priceId, quantity: 1 }]
          : [
              {
                quantity: 1,
                price_data: {
                  currency: paymentConfig.currency.toLowerCase(),
                  unit_amount: Math.round(amount * 100),
                  recurring: { interval: cycle === 'annual' ? 'year' : 'month' },
                  product_data: { name: `CotizaFácil ${plan.id} (${cycle})` },
                },
              },
            ],
        customer_email: email,
        client_reference_id: userId,
        success_url: `${origin}/assinatura?status=ok`,
        cancel_url: `${origin}/planos?status=cancel`,
        metadata: { userId, plan: plan.id, cycle, reference: planReference(plan.id, cycle) },
        subscription_data: {
          metadata: { userId, plan: plan.id, cycle },
          ...(paymentConfig.trialDays > 0 ? { trial_period_days: paymentConfig.trialDays } : {}),
        },
      });

      return NextResponse.json({ url: session.url, provider: 'stripe', amount, currency: paymentConfig.currency });
    } catch (e: any) {
      return NextResponse.json({ error: e?.message || 'Erro no Stripe' }, { status: 500 });
    }
  }

  // ===================== MERCADO PAGO =====================
  // Assinatura sem plano associado (preapproval) com pagamento autorizado.
  try {
    const backUrl = paymentConfig.backUrl;
    const payload = {
      reason: `CotizaFácil ${plan.id} (${cycle})`,
      external_reference: `${userId}|${plan.id}|${cycle}`,
      payer_email: email,
      back_url: `${backUrl}?status=ok`,
      status: 'pending',
      auto_recurring: {
        frequency: cycle === 'annual' ? 12 : 1,
        frequency_type: 'months',
        transaction_amount: amount,
        currency_id: paymentConfig.currency,
        ...(paymentConfig.trialDays > 0
          ? { free_trial: { frequency: paymentConfig.trialDays, frequency_type: 'days' } }
          : {}),
      },
    };

    const res = await fetch('https://api.mercadopago.com/preapproval', {
      method: 'POST',
      headers: {
        Authorization: `Bearer ${paymentConfig.credentials.mpAccessToken}`,
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(payload),
    });

    const data = await res.json();
    if (!res.ok) {
      return NextResponse.json({ error: data?.message || 'Erro no Mercado Pago' }, { status: 502 });
    }

    // guarda o vínculo preapproval <-> usuário para o webhook conseguir reconciliar
    if (supabase && userId !== 'demo-user' && data?.id) {
      await supabase
        .from('profiles')
        .update({ provider_subscription_id: String(data.id) })
        .eq('id', userId);
    }

    return NextResponse.json({
      url: data.init_point || data.sandbox_init_point,
      provider: 'mercadopago',
      preapproval_id: data.id,
      amount,
      currency: paymentConfig.currency,
    });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Erro no Mercado Pago' }, { status: 500 });
  }
}
