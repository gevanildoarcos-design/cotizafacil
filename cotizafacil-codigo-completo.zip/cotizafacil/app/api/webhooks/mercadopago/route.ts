import { NextResponse } from 'next/server';
import { createHmac, timingSafeEqual } from 'node:crypto';
import { getServiceSupabase } from '@/lib/supabase/server';
import { paymentConfig } from '@/config/payment.config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/webhooks/mercadopago
 * Cadastre esta URL em "Suas integrações → Webhooks" no painel do Mercado Pago.
 * Eventos de assinatura: topic=subscription_preapproval e topic=subscription_authorized_payment.
 *
 * O Mercado Pago envia { type | topic, data: { id } } e, para consultar o objeto,
 * chamamos GET /preapproval/{id} com o access token.
 */

function verifySignature(req: Request, dataId: string): boolean {
  const secret = paymentConfig.credentials.mpWebhookSecret;
  if (!secret) return true; // sem segredo configurado não bloqueia (útil em testes locais)

  const xSignature = req.headers.get('x-signature') || '';
  const xRequestId = req.headers.get('x-request-id') || '';
  const ts = /ts=([^,;]+)/.exec(xSignature)?.[1] || '';
  const v1 = /v1=([^,;]+)/.exec(xSignature)?.[1] || '';
  if (!ts || !v1) return false;

  const manifest = `id:${dataId};request-id:${xRequestId};ts:${ts};`;
  const hmac = createHmac('sha256', secret).update(manifest).digest('hex');
  try {
    return timingSafeEqual(Buffer.from(hmac, 'utf8'), Buffer.from(v1, 'utf8'));
  } catch {
    return false;
  }
}

export async function POST(req: Request) {
  const url = new URL(req.url);
  let body: any = {};
  try {
    body = await req.json();
  } catch {
    body = {};
  }

  const type = body?.type || body?.topic || url.searchParams.get('type') || url.searchParams.get('topic') || '';
  const dataId = String(body?.data?.id || body?.id || url.searchParams.get('data.id') || url.searchParams.get('id') || '');

  if (!verifySignature(req, dataId)) {
    return NextResponse.json({ error: 'assinatura inválida' }, { status: 401 });
  }

  const supabase = getServiceSupabase();
  const token = paymentConfig.credentials.mpAccessToken;

  // Sem banco configurado: confirma recebimento (o MP reenvia se retornarmos erro).
  if (!supabase || !token) return NextResponse.json({ received: true, persisted: false, type });

  try {
    if (type === 'subscription_preapproval' && dataId) {
      const res = await fetch(`https://api.mercadopago.com/preapproval/${dataId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const pre = await res.json();
      if (!res.ok) return NextResponse.json({ received: true, error: pre?.message });

      // external_reference = "userId|planId|cycle"
      const [userId, planId, cycle] = String(pre.external_reference || '').split('|');
      const status = String(pre.status || ''); // pending | authorized | paused | cancelled
      if (!userId) return NextResponse.json({ received: true, unmatched: true, preapproval: dataId });

      const active = status === 'authorized';
      const patch: Record<string, any> = {
        subscription_status: active ? 'active' : status === 'cancelled' ? 'canceled' : 'past_due',
        provider_subscription_id: String(pre.id),
        plan: active ? planId || 'starter' : status === 'cancelled' ? 'free' : planId || 'starter',
        billing_cycle: cycle === 'annual' ? 'annual' : 'monthly',
        next_charge_at: pre.next_payment_date || null,
      };
      if (active) patch.reminder_sent_at = null;

      await supabase.from('profiles').update(patch).eq('id', userId);

      await supabase.from('subscriptions').insert({
        user_id: userId,
        plan_id: planId || 'starter',
        billing_cycle: cycle === 'annual' ? 'annual' : 'monthly',
        status: active ? 'active' : status,
        provider: 'mercadopago',
        provider_id: String(pre.id),
        current_period_end: pre.next_payment_date || null,
        canceled_at: status === 'cancelled' ? new Date().toISOString() : null,
        raw_event: pre,
      });
    }

    if (type === 'subscription_authorized_payment' && dataId) {
      const res = await fetch(`https://api.mercadopago.com/authorized_payments/${dataId}`, {
        headers: { Authorization: `Bearer ${token}` },
      });
      const pay = await res.json();
      if (!res.ok) return NextResponse.json({ received: true, error: pay?.message });

      const preapprovalId = String(pay.preapproval_id || '');
      const { data: prof } = await supabase
        .from('profiles')
        .select('id')
        .eq('provider_subscription_id', preapprovalId)
        .maybeSingle();

      if (prof?.id) {
        await supabase.from('payments').upsert(
          {
            user_id: prof.id,
            amount: Number(pay.transaction_amount || 0),
            currency: pay.currency_id || paymentConfig.currency,
            status: String(pay.status || '') === 'approved' || pay.status === 'processed' ? 'paid' : 'pending',
            provider: 'mercadopago',
            provider_payment_id: String(pay.id),
            paid_at: pay.date_created || new Date().toISOString(),
          },
          { onConflict: 'provider,provider_payment_id' },
        );
      } else {
        // fallback: guarda pelo id do preapproval quando não há perfil vinculado
        await supabase.from('payments').upsert(
          {
            user_id: prof?.id || null,
            amount: Number(pay.transaction_amount || 0),
            currency: pay.currency_id || paymentConfig.currency,
            status: 'paid',
            provider: 'mercadopago',
            provider_payment_id: String(pay.id),
            paid_at: pay.date_created || new Date().toISOString(),
          },
          { onConflict: 'provider,provider_payment_id' },
        ).select();
      }
    }

    return NextResponse.json({ received: true, type });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Erro ao processar notificação' }, { status: 500 });
  }
}

/** O Mercado Pago também faz um GET de validação ao salvar a URL. */
export async function GET() {
  return NextResponse.json({ ok: true, endpoint: 'mercadopago-webhook' });
}
