import { NextResponse } from 'next/server';
import { getServiceSupabase } from '@/lib/supabase/server';
import { paymentConfig } from '@/config/payment.config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/webhooks/stripe
 * Eventos tratados:
 *  - checkout.session.completed      -> ativa o plano (userId vem de client_reference_id e metadata)
 *  - customer.subscription.updated   -> sincroniza status / próxima cobrança / cancelamento agendado
 *  - customer.subscription.deleted   -> volta ao gratuito
 *  - invoice.paid                    -> registra o pagamento no histórico
 * Configure a URL: https://SEU-DOMINIO/api/webhooks/stripe
 */
export async function POST(req: Request) {
  const raw = await req.text();
  const signature = req.headers.get('stripe-signature') || '';

  let event: any;
  try {
    const Stripe = (await import('stripe')).default;
    const stripe = new Stripe(paymentConfig.credentials.stripeSecretKey);
    event = paymentConfig.credentials.stripeWebhookSecret
      ? stripe.webhooks.constructEvent(raw, signature, paymentConfig.credentials.stripeWebhookSecret)
      : JSON.parse(raw);
  } catch (e: any) {
    return NextResponse.json({ error: `Assinatura do webhook inválida: ${e?.message}` }, { status: 400 });
  }

  const supabase = getServiceSupabase();
  if (!supabase) {
    // sem banco configurado apenas confirmamos o recebimento
    return NextResponse.json({ received: true, persisted: false });
  }

  const obj = event?.data?.object || {};

  try {
    switch (event.type) {
      case 'checkout.session.completed': {
        const userId = obj.client_reference_id || obj.metadata?.userId;
        const plan = obj.metadata?.plan || 'starter';
        const cycle = obj.metadata?.cycle || 'monthly';
        if (userId) {
          await supabase
            .from('profiles')
            .update({
              plan,
              billing_cycle: cycle,
              subscription_status: 'active',
              provider_customer_id: obj.customer || null,
              provider_subscription_id: obj.subscription || null,
            })
            .eq('id', userId);

          await supabase.from('subscriptions').insert({
            user_id: userId,
            plan_id: plan,
            billing_cycle: cycle,
            status: 'active',
            provider: 'stripe',
            provider_id: obj.subscription || obj.id,
            raw_event: event,
          });
        }
        break;
      }

      case 'invoice.paid': {
        const userId = obj.subscription_details?.metadata?.userId || obj.metadata?.userId;
        if (userId) {
          await supabase.from('payments').upsert(
            {
              user_id: userId,
              amount: (obj.amount_paid || 0) / 100,
              currency: (obj.currency || 'brl').toUpperCase(),
              status: 'paid',
              provider: 'stripe',
              provider_payment_id: obj.id,
              plan_id: obj.subscription_details?.metadata?.plan || null,
              billing_cycle: obj.subscription_details?.metadata?.cycle || null,
              paid_at: new Date().toISOString(),
            },
            { onConflict: 'provider,provider_payment_id' },
          );
          const periodEnd = obj.lines?.data?.[0]?.period?.end;
          await supabase
            .from('profiles')
            .update({
              subscription_status: 'active',
              ...(periodEnd ? { next_charge_at: new Date(periodEnd * 1000).toISOString(), reminder_sent_at: null } : {}),
            })
            .eq('id', userId);
        }
        break;
      }

      case 'customer.subscription.updated':
      case 'customer.subscription.deleted': {
        const userId = obj.metadata?.userId;
        const canceled = event.type === 'customer.subscription.deleted' || obj.status === 'canceled';
        if (userId) {
          await supabase
            .from('profiles')
            .update({
              plan: canceled ? 'free' : obj.metadata?.plan || 'starter',
              subscription_status: canceled ? 'canceled' : obj.status === 'past_due' ? 'past_due' : 'active',
              next_charge_at: obj.current_period_end ? new Date(obj.current_period_end * 1000).toISOString() : null,
            })
            .eq('id', userId);

          await supabase.from('subscriptions').insert({
            user_id: userId,
            plan_id: obj.metadata?.plan || 'starter',
            billing_cycle: obj.metadata?.cycle || 'monthly',
            status: canceled ? 'canceled' : obj.status,
            provider: 'stripe',
            provider_id: obj.id,
            current_period_end: obj.current_period_end ? new Date(obj.current_period_end * 1000).toISOString() : null,
            canceled_at: canceled ? new Date().toISOString() : null,
            raw_event: event,
          });
        }
        break;
      }

      case 'invoice.payment_failed': {
        const userId = obj.subscription_details?.metadata?.userId || obj.metadata?.userId;
        if (userId) await supabase.from('profiles').update({ subscription_status: 'past_due' }).eq('id', userId);
        break;
      }

      default:
        break;
    }

    return NextResponse.json({ received: true, type: event.type });
  } catch (e: any) {
    return NextResponse.json({ error: e?.message || 'Erro ao processar evento' }, { status: 500 });
  }
}
