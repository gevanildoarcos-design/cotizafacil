import { NextResponse } from 'next/server';
import { getServiceSupabase } from '@/lib/supabase/server';
import { paymentConfig } from '@/config/payment.config';

export const runtime = 'nodejs';
export const dynamic = 'force-dynamic';

/**
 * POST /api/subscription/cancel
 * Cancela a assinatura no gateway ativo. O webhook confirma a mudança e
 * coloca o usuário de volta no plano gratuito.
 */
export async function POST(req: Request) {
  const supabase = getServiceSupabase();
  if (!supabase) return NextResponse.json({ ok: true, mode: 'demo' });

  const auth = req.headers.get('authorization') || '';
  let token = auth.startsWith('Bearer ') ? auth.slice(7) : '';
  if (!token) {
    // permite também o cookie de sessão (chamada direta do app)
    const cookie = req.headers.get('cookie') || '';
    const match = /sb-[^=]+-auth-token=([^;]+)/.exec(cookie);
    if (match) token = decodeURIComponent(match[1]);
  }

  const { data: userData } = token ? await supabase.auth.getUser(token) : ({ data: {} } as any);
  const userId = userData?.user?.id;
  if (!userId) return NextResponse.json({ error: 'não autenticado' }, { status: 401 });

  const { data: profile } = await supabase
    .from('profiles')
    .select('provider_subscription_id')
    .eq('id', userId)
    .maybeSingle();

  const providerId = profile?.provider_subscription_id;

  try {
    if (paymentConfig.provider === 'stripe' && providerId && paymentConfig.credentials.stripeSecretKey) {
      const Stripe = (await import('stripe')).default;
      const stripe = new Stripe(paymentConfig.credentials.stripeSecretKey);
      await stripe.subscriptions.cancel(providerId);
    }

    if (paymentConfig.provider === 'mercadopago' && providerId && paymentConfig.credentials.mpAccessToken) {
      // preapproval: paused ou cancelled
      await fetch(`https://api.mercadopago.com/preapproval/${providerId}`, {
        method: 'PUT',
        headers: {
          Authorization: `Bearer ${paymentConfig.credentials.mpAccessToken}`,
          'Content-Type': 'application/json',
        },
        body: JSON.stringify({ status: 'cancelled' }),
      });
    }
  } catch (e: any) {
    return NextResponse.json({ ok: false, error: e?.message || 'Erro ao cancelar no gateway' }, { status: 502 });
  }

  await supabase
    .from('profiles')
    .update({ plan: 'free', subscription_status: 'canceled', next_charge_at: null })
    .eq('id', userId);

  await supabase
    .from('subscriptions')
    .update({ status: 'canceled', canceled_at: new Date().toISOString() })
    .eq('user_id', userId)
    .eq('status', 'active');

  return NextResponse.json({ ok: true });
}
