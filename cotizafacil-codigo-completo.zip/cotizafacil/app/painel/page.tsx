'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import QuoteCard from '@/components/QuoteCard';
import { useApp } from '@/components/AppProvider';
import { quotes } from '@/lib/repo';
import { formatBRL } from '@/lib/plans';
import { formatLongDate } from '@/lib/i18n';
import type { Quote } from '@/lib/types';

function ymd(d: Date) {
  return `${d.getFullYear()}-${`${d.getMonth() + 1}`.padStart(2, '0')}-${`${d.getDate()}`.padStart(2, '0')}`;
}

export default function PainelPage() {
  const { t, user, locale } = useApp();
  const [list, setList] = useState<Quote[]>([]);
  const [loading, setLoading] = useState(true);

  async function load() {
    if (!user) return;
    setLoading(true);
    try {
      setList(await quotes.list(user.id));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const stats = useMemo(() => {
    const today = ymd(new Date());
    return {
      total: list.length,
      pending: list.filter((q) => q.status === 'pending').length,
      today: list.filter((q) => String(q.delivery_date || '').slice(0, 10) === today).length,
      paidWeek: list
        .filter((q) => q.status === 'paid' || q.status === 'delivered')
        .reduce((s, q) => s + Number(q.value || 0), 0),
    };
  }, [list]);

  return (
    <AppShell
      title={t('nav.home')}
      subtitle={t('app.tagline')}
      requireAuth
      action={
        <Link href="/novo" className="btn btn-primary">
          ➕ {t('nav.new')}
        </Link>
      }
    >
      <section className="grid grid-4">
        <div className="card card-tight">
          <div className="tiny muted">{t('nav.history')}</div>
          <div className="plan-price" style={{ fontSize: '1.6rem' }}>{stats.total}</div>
        </div>
        <div className="card card-tight">
          <div className="tiny muted">{t('status.pending')}</div>
          <div className="plan-price" style={{ fontSize: '1.6rem' }}>{stats.pending}</div>
        </div>
        <div className="card card-tight">
          <div className="tiny muted">{t('quote.deliveryAt')} {t('quote.deliveryDate')}</div>
          <div className="plan-price" style={{ fontSize: '1.6rem' }}>{stats.today}</div>
        </div>
        <div className="card card-tight">
          <div className="tiny muted">{t('clients.total')}</div>
          <div className="plan-price" style={{ fontSize: '1.6rem' }}>{formatBRL(stats.paidWeek)}</div>
        </div>
      </section>

      <section className="section">
        <div className="grid grid-3">
          <Link href="/novo" className="card center">
            <div style={{ fontSize: 30 }}>➕</div>
            <strong>{t('nav.new')}</strong>
            <p className="muted small" style={{ marginBottom: 0 }}>{t('quote.sub')}</p>
          </Link>
          <Link href="/historico" className="card center">
            <div style={{ fontSize: 30 }}>📅</div>
            <strong>{t('nav.history')}</strong>
            <p className="muted small" style={{ marginBottom: 0 }}>{t('history.sub')}</p>
          </Link>
          <Link href="/clientes" className="card center">
            <div style={{ fontSize: 30 }}>👥</div>
            <strong>{t('nav.clients')}</strong>
            <p className="muted small" style={{ marginBottom: 0 }}>{t('clients.sub')}</p>
          </Link>
        </div>
      </section>

      <section className="section">
        <div className="row-between">
          <h2 style={{ marginBottom: 0 }}>{t('history.ordersOn')}</h2>
          <Link href="/historico" className="btn btn-ghost btn-sm">
            {t('history.calendar')} →
          </Link>
        </div>

        {loading ? (
          <div className="center" style={{ padding: 30 }}>
            <div className="spinner" style={{ margin: '0 auto' }} />
          </div>
        ) : list.length === 0 ? (
          <div className="card center">
            <p className="muted">{t('history.empty')}</p>
            <Link href="/novo" className="btn btn-primary">
              {t('history.emptyCta')}
            </Link>
          </div>
        ) : (
          <div className="grid" style={{ gap: 10, marginTop: 12 }}>
            {list
              .slice()
              .sort((a, b) => String(a.delivery_date || '9999').localeCompare(String(b.delivery_date || '9999')))
              .slice(0, 6)
              .map((q) => (
                <QuoteCard key={q.id} quote={q} onChanged={load} />
              ))}
          </div>
        )}
      </section>

      {list.some((q) => q.delivery_date) && (
        <p className="tiny muted">
          {t('quote.deliveryAt')}: {formatLongDate(list[0].delivery_date, locale)}
        </p>
      )}
    </AppShell>
  );
}
