import type { Metadata, Viewport } from 'next';
import './globals.css';
import { AppProvider } from '@/components/AppProvider';

export const metadata: Metadata = {
  title: 'CotizaFácil · Orçamentos bonitos e rápidos em 30 segundos',
  description:
    'Gere orçamentos profissionais, envie por WhatsApp e controle entregas e pagamentos. Para padarias e confeitarias. PT/ES.',
  manifest: '/manifest.json',
  applicationName: 'CotizaFácil',
  appleWebApp: { capable: true, statusBarStyle: 'default', title: 'CotizaFácil' },
  icons: { icon: '/icon-192.png', apple: '/icon-192.png' },
  openGraph: {
    title: 'CotizaFácil',
    description: 'Orçamentos bonitos e rápidos em 30 segundos',
    type: 'website',
  },
};

export const viewport: Viewport = {
  themeColor: '#F5B301',
  width: 'device-width',
  initialScale: 1,
  maximumScale: 5,
};

export default function RootLayout({ children }: { children: React.ReactNode }) {
  return (
    <html lang="pt-BR">
      <body>
        <AppProvider>{children}</AppProvider>
      </body>
    </html>
  );
}
