'use client';

import Link from 'next/link';
import AppShell from '@/components/AppShell';
import LanguageSwitch from '@/components/LanguageSwitch';
import { useApp } from '@/components/AppProvider';

export default function LandingPage() {
  const { t, user } = useApp();

  return (
    <AppShell>
      <section className="hero center">
        <div className="badge badge-info">{t('landing.badge')}</div>
        <h1 style={{ marginTop: 14 }}>{t('landing.h1')}</h1>
        <p style={{ margin: '0 auto 22px' }}>{t('landing.sub')}</p>

        <div className="row" style={{ justifyContent: 'center' }}>
          <Link href={user ? '/novo' : '/entrar?tab=signup'} className="btn btn-primary">
            🚀 {user ? t('nav.new') : t('landing.startFree')}
          </Link>
          <Link href={user ? '/painel' : '/entrar'} className="btn btn-ghost">
            {user ? t('nav.home') : t('landing.login')}
          </Link>
          <Link href="/planos" className="btn btn-ghost">
            ⭐ {t('plans.title')}
          </Link>
        </div>

        <div className="row" style={{ justifyContent: 'center', marginTop: 14 }}>
          <LanguageSwitch />
        </div>
      </section>

      <section className="section">
        <div className="grid grid-3">
          {[
            ['🧰', 'landing.hl1'],
            ['📲', 'landing.hl2'],
            ['🗂️', 'landing.hl3'],
          ].map(([ico, key]) => (
            <div className="card hl" key={key}>
              <span className="hl-ico">{ico}</span>
              <span>{t(key)}</span>
            </div>
          ))}
        </div>
      </section>

      <section className="section">
        <h2 className="center">{t('landing.how')}</h2>
        <div className="grid grid-3" style={{ marginTop: 16 }}>
          {[
            ['step1t', 'step1d'],
            ['step2t', 'step2d'],
            ['step3t', 'step3d'],
          ].map(([titleKey, descKey], i) => (
            <div className="card" key={titleKey}>
              <div className="row" style={{ marginBottom: 8 }}>
                <span className="step-num">{i + 1}</span>
                <strong>{t(`landing.${titleKey}`)}</strong>
              </div>
              <p className="muted small" style={{ marginBottom: 0 }}>
                {t(`landing.${descKey}`)}
              </p>
            </div>
          ))}
        </div>
      </section>

      <section className="card center" style={{ background: 'var(--amarelo-claro)', border: 0 }}>
        <h3>🎁 {t('landing.freeNote')}</h3>
        <div className="row" style={{ justifyContent: 'center', marginTop: 10 }}>
          <Link href="/planos" className="btn btn-brown">
            {t('plans.title')}
          </Link>
          <Link href="/entrar?tab=signup" className="btn btn-primary">
            {t('landing.startFree')}
          </Link>
        </div>
      </section>

      <section className="section center">
        <p className="muted">{t('landing.install')}</p>
      </section>

      <footer className="center section tiny muted">
        <p>
          {t('landing.footer')} · <Link href="/planos">{t('plans.title')}</Link>
        </p>
        <p>CotizaFácil © {new Date().getFullYear()}</p>
      </footer>
    </AppShell>
  );
}
