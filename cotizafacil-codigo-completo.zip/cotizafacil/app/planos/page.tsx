'use client';

import { useState } from 'react';
import { useRouter } from 'next/navigation';
import AppShell from '@/components/AppShell';
import PlanCards from '@/components/PlanCards';
import { useApp } from '@/components/AppProvider';
import { activatePlanLocal, payments, profiles } from '@/lib/repo';
import { priceFor, getPlan, type BillingCycle, type PlanId } from '@/lib/plans';
import { isPaymentGatewayConfigured } from '@/config/payment.config';

export default function PlanosPage() {
  const { t, user, profile, setProfile, toast, setLocale, locale } = useApp();
  const router = useRouter();
  const [busyPlan, setBusyPlan] = useState<string | null>(null);

  async function startCheckout(planId: PlanId, cycle: BillingCycle) {
    if (!user) {
      router.push('/entrar?tab=signup');
      return;
    }
    if (planId === 'free') {
      const patch = await profiles.update({ plan: 'free', subscription_status: 'inactive', next_charge_at: null });
      setProfile(patch);
      toast(t('plans.continueFree') + ' ✓');
      router.push('/painel');
      return;
    }

    setBusyPlan(planId);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: planId, cycle, locale }),
      });
      const data = await res.json();

      if (data?.url) {
        window.location.href = data.url;
        return;
      }

      // Sem gateway configurado: ativa em modo demonstração para o usuário testar o fluxo.
      if (data?.mode === 'demo' && profile) {
        const amount = priceFor(getPlan(planId), cycle);
        const patch = await activatePlanLocal(profile, planId, cycle, amount, payments.add);
        setProfile({ ...profile, ...patch } as any);
        toast(t('sub.gatewayDemo'), 'info');
        router.push('/assinatura');
        return;
      }

      toast(data?.error || t('sub.checkoutError'), 'warn');
    } catch (e: any) {
      toast(e?.message || t('sub.checkoutError'), 'warn');
    } finally {
      setBusyPlan(null);
    }
  }

  return (
    <AppShell title={t('plans.title')} subtitle={t('plans.sub')}>
      {!isPaymentGatewayConfigured() && (
        <div className="alert alert-info small">
          🔧 {t('sub.gatewayDemo')} — configure <code>PAYMENT_PROVIDER</code> + chaves em <code>.env.local</code> (veja
          <code> config/payment.config.ts</code>).
        </div>
      )}

      <PlanCards onSelect={startCheckout} currentPlan={profile?.plan} busyPlan={busyPlan} ctaLogin={!user} />

      <section className="card section">
        <h3>{t('settings.language')}</h3>
        <div className="row">
          <button className="btn btn-ghost" onClick={() => setLocale(locale === 'pt' ? 'es' : 'pt')}>
            🌎 {locale === 'pt' ? 'Cambiar a Español' : 'Trocar para Português'}
          </button>
        </div>
      </section>
    </AppShell>
  );
}
