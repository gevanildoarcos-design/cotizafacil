'use client';

import { Suspense, useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import AppShell from '@/components/AppShell';
import { useApp } from '@/components/AppProvider';
import { clients as clientsRepo, quotes } from '@/lib/repo';
import { suggestPrice } from '@/lib/pricing';
import { formatBRL } from '@/lib/plans';
import { buildQuoteMessage, buildWhatsappLink, normalizePhone } from '@/lib/whatsapp';
import type { Client, ProductType, Quote } from '@/lib/types';

const PRODUCTS: { id: ProductType; emoji: string }[] = [
  { id: 'torta', emoji: '🥧' },
  { id: 'bolo', emoji: '🎂' },
  { id: 'doces', emoji: '🧁' },
  { id: 'pao', emoji: '🥖' },
  { id: 'outro', emoji: '✨' },
];

const empty = {
  product: 'bolo' as ProductType,
  size: '',
  flavor: '',
  filling: '',
  decoration: '',
  message: '',
  delivery_date: '',
  delivery_time: '',
  customer_name: '',
  customer_phone: '',
  value: 0,
  notes: '',
};

function NovoInner() {
  const { t, locale, user, profile, quota, refreshQuota, toast } = useApp();
  const router = useRouter();
  const params = useSearchParams();
  const editId = params.get('id');

  const [form, setForm] = useState({ ...empty });
  const [valueRaw, setValueRaw] = useState('0');
  const [autoValue, setAutoValue] = useState(true);
  const [saving, setSaving] = useState(false);
  const [savedId, setSavedId] = useState<string | null>(null);
  const [clientList, setClientList] = useState<Client[]>([]);
  const [loadingEdit, setLoadingEdit] = useState(!!editId);

  // ---- carrega clientes para autocompletar ----
  useEffect(() => {
    if (!user) return;
    clientsRepo.list(user.id).then(setClientList).catch(() => {});
  }, [user?.id]);

  // ---- modo edição ----
  useEffect(() => {
    if (!editId || !user) return;
    let alive = true;
    quotes
      .list(user.id)
      .then((all) => {
        if (!alive) return;
        const q = all.find((x) => x.id === editId);
        if (q) {
          setForm({
            product: q.product as ProductType,
            size: q.size || '',
            flavor: q.flavor || '',
            filling: q.filling || '',
            decoration: q.decoration || '',
            message: q.message || '',
            delivery_date: q.delivery_date ? String(q.delivery_date).slice(0, 10) : '',
            delivery_time: q.delivery_time || '',
            customer_name: q.customer_name || '',
            customer_phone: q.customer_phone || '',
            value: Number(q.value || 0),
            notes: '',
          });
          setValueRaw(String(q.value || 0));
          setAutoValue(false);
          setSavedId(q.id);
        }
      })
      .finally(() => alive && setLoadingEdit(false));
    return () => {
      alive = false;
    };
  }, [editId, user?.id]);

  const suggested = useMemo(
    () =>
      suggestPrice({
        product: form.product,
        size: form.size,
        filling: form.filling,
        decoration: form.decoration,
      }),
    [form.product, form.size, form.filling, form.decoration],
  );

  useEffect(() => {
    if (autoValue) setValueRaw(String(suggested));
  }, [suggested, autoValue]);

  const value = Number(String(valueRaw).replace(',', '.')) || 0;

  const previewQuote: Quote = useMemo(
    () => ({
      id: savedId || 'preview',
      user_id: user?.id || '',
      client_id: null,
      customer_name: form.customer_name || '—',
      customer_phone: form.customer_phone || '',
      product: form.product,
      size: form.size,
      flavor: form.flavor,
      filling: form.filling,
      decoration: form.decoration,
      message: form.message,
      delivery_date: form.delivery_date || null,
      delivery_time: form.delivery_time,
      value,
      status: 'pending',
      store_name: profile?.store_name || '',
      created_at: new Date().toISOString(),
    }),
    [form, value, savedId, user?.id, profile?.store_name],
  );

  const blocked = !!quota && quota.reached && !editId;

  function set<K extends keyof typeof form>(key: K, v: (typeof form)[K]) {
    setForm((f) => ({ ...f, [key]: v }));
  }

  async function persist(): Promise<Quote | null> {
    if (!user) {
      router.push('/entrar');
      return null;
    }
    if (!form.customer_name || !value) {
      toast(t('quote.required'), 'warn');
      return null;
    }
    setSaving(true);
    try {
      const client = await clientsRepo.ensure(form.customer_name, form.customer_phone, user.id, form.notes);
      const record = await quotes.create(
        {
          id: savedId || undefined,
          client_id: client.id,
          customer_name: form.customer_name,
          customer_phone: form.customer_phone,
          product: form.product,
          size: form.size,
          flavor: form.flavor,
          filling: form.filling,
          decoration: form.decoration,
          message: form.message,
          delivery_date: form.delivery_date || null,
          delivery_time: form.delivery_time,
          value,
          status: 'pending',
          store_name: profile?.store_name || '',
        },
        user.id,
      );
      setSavedId(record.id);
      await refreshQuota();
      return record;
    } catch (e: any) {
      const msg = String(e?.message || '');
      if (msg.includes('free_limit_reached')) toast(t('quote.limitReached'), 'warn');
      else toast(msg || 'Erro', 'warn');
      return null;
    } finally {
      setSaving(false);
    }
  }

  async function onSave() {
    const r = await persist();
    if (r) {
      toast(t('quote.saved') + ' ✓');
      router.push('/historico');
    }
  }

  async function onWhatsapp() {
    let record = previewQuote;
    if (user) {
      const saved = await persist();
      if (saved) record = saved;
      else if (!savedId) return;
    }
    window.open(
      buildWhatsappLink(record, { language: locale, storeName: profile?.store_name }),
      '_blank',
      'noopener',
    );
  }

  async function onPdf() {
    let record = previewQuote;
    if (user) {
      const saved = await persist();
      if (saved) record = saved;
      else if (!savedId) return;
    }
    const { generateQuotePdf } = await import('@/lib/pdf');
    await generateQuotePdf({
      quote: record,
      locale,
      storeName: profile?.store_name,
      storePhone: profile?.store_phone,
      logoDataUrl: profile?.store_logo || null,
    });
  }

  function pickClient(c: Client) {
    setForm((f) => ({ ...f, customer_name: c.name, customer_phone: c.phone, notes: c.notes || '' }));
  }

  return (
    <AppShell
      title={editId ? t('quote.editing') : t('quote.title')}
      subtitle={t('quote.sub')}
      requireAuth
      action={
        <Link href="/painel" className="btn btn-ghost btn-sm">
          {t('common.back')}
        </Link>
      }
    >
      {blocked && (
        <div className="alert alert-warn">
          <strong>{t('quote.limitReached')}</strong>
          <div style={{ marginTop: 8 }}>
            <Link href="/planos" className="btn btn-primary btn-sm">
              ⭐ {t('quote.limitReachedCta')}
            </Link>
          </div>
        </div>
      )}

      {loadingEdit ? (
        <div className="center" style={{ padding: 40 }}>
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : (
        <div className="grid grid-2" style={{ alignItems: 'start' }}>
          {/* ------------------ formulário ------------------ */}
          <div>
            <div className="card">
              <h3>{t('quote.product')}</h3>
              <div className="chips">
                {PRODUCTS.map((p) => (
                  <button
                    key={p.id}
                    type="button"
                    className="chip"
                    aria-pressed={form.product === p.id}
                    onClick={() => set('product', p.id)}
                  >
                    {p.emoji} {t(`quote.${p.id}`)}
                  </button>
                ))}
              </div>

              <div style={{ marginTop: 16 }}>
                <label className="field">
                  <span className="label">{t('quote.size')}</span>
                  <input
                    className="input"
                    value={form.size}
                    onChange={(e) => set('size', e.target.value)}
                    placeholder={t('quote.sizePh')}
                  />
                </label>
                <label className="field">
                  <span className="label">{t('quote.flavor')}</span>
                  <input
                    className="input"
                    value={form.flavor}
                    onChange={(e) => set('flavor', e.target.value)}
                    placeholder={t('quote.flavorPh')}
                  />
                </label>
                <label className="field">
                  <span className="label">{t('quote.filling')}</span>
                  <input
                    className="input"
                    value={form.filling}
                    onChange={(e) => set('filling', e.target.value)}
                    placeholder={t('quote.fillingPh')}
                  />
                </label>
                <label className="field">
                  <span className="label">{t('quote.decoration')}</span>
                  <input
                    className="input"
                    value={form.decoration}
                    onChange={(e) => set('decoration', e.target.value)}
                    placeholder={t('quote.decorationPh')}
                  />
                </label>
                <label className="field">
                  <span className="label">{t('quote.message')}</span>
                  <input
                    className="input"
                    value={form.message}
                    onChange={(e) => set('message', e.target.value)}
                    placeholder={t('quote.messagePh')}
                  />
                </label>

                <div className="grid grid-2">
                  <label className="field">
                    <span className="label">{t('quote.deliveryDate')}</span>
                    <input
                      className="input"
                      type="date"
                      value={form.delivery_date}
                      onChange={(e) => set('delivery_date', e.target.value)}
                    />
                  </label>
                  <label className="field">
                    <span className="label">{t('quote.deliveryTime')}</span>
                    <input
                      className="input"
                      type="time"
                      value={form.delivery_time}
                      onChange={(e) => set('delivery_time', e.target.value)}
                    />
                  </label>
                </div>
              </div>
            </div>

            <div className="card section">
              <h3>👤 {t('quote.customer')}</h3>
              <label className="field">
                <span className="label">{t('quote.customerName')}</span>
                <input
                  className="input"
                  value={form.customer_name}
                  onChange={(e) => set('customer_name', e.target.value)}
                  placeholder="Maria"
                  list="clientes"
                />
                <datalist id="clientes">
                  {clientList.map((c) => (
                    <option key={c.id} value={c.name} />
                  ))}
                </datalist>
              </label>

              {clientList.length > 0 && (
                <div className="chips" style={{ marginBottom: 12 }}>
                  {clientList.slice(0, 6).map((c) => (
                    <button key={c.id} type="button" className="chip" onClick={() => pickClient(c)}>
                      {c.name}
                    </button>
                  ))}
                </div>
              )}

              <label className="field">
                <span className="label">{t('quote.customerPhone')}</span>
                <input
                  className="input"
                  value={form.customer_phone}
                  onChange={(e) => set('customer_phone', e.target.value)}
                  placeholder={t('quote.phonePh')}
                  inputMode="tel"
                />
                {form.customer_phone && (
                  <span className="hint">WhatsApp: +{normalizePhone(form.customer_phone)}</span>
                )}
              </label>
              <label className="field" style={{ marginBottom: 0 }}>
                <span className="label">
                  {t('quote.clientNotes')} <span className="hint">({t('common.optional')})</span>
                </span>
                <input
                  className="input"
                  value={form.notes}
                  onChange={(e) => set('notes', e.target.value)}
                  placeholder={t('clients.notesPh')}
                />
              </label>
            </div>

            <div className="card section">
              <div className="row-between">
                <h3 style={{ marginBottom: 0 }}>💰 {t('quote.value')}</h3>
                <label className="row small" style={{ gap: 6, cursor: 'pointer' }}>
                  <input type="checkbox" checked={autoValue} onChange={(e) => setAutoValue(e.target.checked)} />
                  {t('quote.autoCalc')}
                </label>
              </div>

              <div className="row" style={{ marginTop: 12, alignItems: 'flex-end' }}>
                <label className="field" style={{ flex: 1, marginBottom: 0 }}>
                  <span className="label">R$</span>
                  <input
                    className="input"
                    type="number"
                    step="0.01"
                    min="0"
                    value={valueRaw}
                    onChange={(e) => {
                      setAutoValue(false);
                      setValueRaw(e.target.value);
                    }}
                  />
                </label>
                <button
                  type="button"
                  className="btn btn-ghost"
                  onClick={() => {
                    setAutoValue(true);
                    setValueRaw(String(suggested));
                  }}
                >
                  ✨ {t('quote.suggested')} {formatBRL(suggested)}
                </button>
              </div>

              <div className="total-box" style={{ marginTop: 14 }}>
                <span>{t('pdf.total')}</span>
                <span className="val">{formatBRL(value)}</span>
              </div>

              <div className="grid grid-3" style={{ marginTop: 14 }}>
                <button className="btn btn-brown" onClick={onPdf} disabled={saving}>
                  📄 {t('quote.generatePdf')}
                </button>
                <button className="btn btn-whats" onClick={onWhatsapp} disabled={saving}>
                  📲 {t('quote.sendWhatsapp')}
                </button>
                <button className="btn btn-primary" onClick={onSave} disabled={saving}>
                  💾 {t('quote.save')}
                </button>
              </div>
            </div>
          </div>

          {/* ------------------ prévia ------------------ */}
          <div className="card">
            <div className="row-between">
              <h3 style={{ marginBottom: 0 }}>{t('quote.preview')}</h3>
              <span className="badge badge-pending">{t('status.pending')}</span>
            </div>
            <p className="tiny muted">{t('pdf.generatedBy')}</p>

            <div className="list-item">
              <div className="list-main">
                <div className="list-title">{profile?.store_name || t('app.name')}</div>
                <div className="list-sub">{profile?.store_phone || ''}</div>
              </div>
              <div className="list-value">{formatBRL(value)}</div>
            </div>

            {[
              [t('pdf.customer'), form.customer_name || '—'],
              [t('pdf.phone'), form.customer_phone || '—'],
              [t('pdf.product'), t(`quote.${form.product}`)],
              [t('pdf.size'), form.size || '—'],
              [t('pdf.flavor'), form.flavor || '—'],
              [t('pdf.filling'), form.filling || '—'],
              [t('pdf.decoration'), form.decoration || '—'],
              [t('pdf.message'), form.message || '—'],
              [t('pdf.delivery'), [form.delivery_date, form.delivery_time].filter(Boolean).join(' · ') || '—'],
            ].map(([k, v]) => (
              <div className="list-item" key={k}>
                <span className="list-sub">{k}</span>
                <strong style={{ textAlign: 'right', maxWidth: '60%' }}>{v}</strong>
              </div>
            ))}

            <p className="tiny muted" style={{ marginTop: 12 }}>{t('pdf.validity')}</p>

            <details className="small">
              <summary style={{ cursor: 'pointer', fontWeight: 700, color: 'var(--marrom)' }}>
                💬 {t('quote.sendWhatsapp')}
              </summary>
              <pre
                style={{
                  whiteSpace: 'pre-wrap',
                  fontSize: '.82rem',
                  background: '#25D36615',
                  padding: 12,
                  borderRadius: 12,
                  marginTop: 8,
                }}
              >
                {buildQuoteMessage(previewQuote, { language: locale, storeName: profile?.store_name })}
              </pre>
            </details>
          </div>
        </div>
      )}
    </AppShell>
  );
}

export default function NovoPage() {
  return (
    <Suspense fallback={<div className="page wrap center">…</div>}>
      <NovoInner />
    </Suspense>
  );
}
