'use client';

import { Suspense, useEffect, useState } from 'react';
import Link from 'next/link';
import { useRouter, useSearchParams } from 'next/navigation';
import AppShell from '@/components/AppShell';
import LanguageSwitch from '@/components/LanguageSwitch';
import { useApp } from '@/components/AppProvider';
import { auth } from '@/lib/repo';
import { LOCALES } from '@/lib/i18n';

function EntrarInner() {
  const { t, locale, refresh, toast } = useApp();
  const router = useRouter();
  const params = useSearchParams();
  const [tab, setTab] = useState<'login' | 'signup'>(params.get('tab') === 'signup' ? 'signup' : 'login');
  const [name, setName] = useState('');
  const [storeName, setStoreName] = useState('');
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');
  const [busy, setBusy] = useState(false);
  const [msg, setMsg] = useState<string | null>(null);

  useEffect(() => {
    if (params.get('tab') === 'signup') setTab('signup');
  }, [params]);

  async function submit(e: React.FormEvent) {
    e.preventDefault();
    setBusy(true);
    setMsg(null);
    try {
      if (tab === 'signup') {
        const res = await auth.signUp(email, password, storeName || name, locale);
        if (!res.ok) {
          setMsg(res.message || 'Erro');
          return;
        }
        if (res.needsConfirm) {
          setMsg(t('auth.checkEmail'));
          return;
        }
        await refresh();
        toast(t('auth.signupCta') + ' ✓');
        router.push('/planos');
      } else {
        const res = await auth.signIn(email, password, locale);
        if (!res.ok) {
          setMsg(res.message || 'Erro');
          return;
        }
        await refresh();
        router.push('/painel');
      }
    } finally {
      setBusy(false);
    }
  }

  async function google() {
    const res = await auth.signInWithGoogle();
    if (!res.ok) setMsg(t('common.loading') + ' …');
  }

  async function demo() {
    setBusy(true);
    try {
      await auth.signInDemo(locale);
      await refresh();
      router.push('/painel');
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell>
      <div className="wrap-narrow" style={{ margin: '0 auto' }}>
        <div className="card">
          <div className="center" style={{ marginBottom: 14 }}>
            <h2>{tab === 'signup' ? t('auth.signupTitle') : t('auth.loginTitle')}</h2>
            <p className="muted small">{tab === 'signup' ? t('auth.signupSub') : t('auth.loginSub')}</p>
          </div>

          <div className="center" style={{ marginBottom: 16 }}>
            <div className="label" style={{ textAlign: 'center' }}>
              {t('auth.langTitle')}
            </div>
            <div className="row" style={{ justifyContent: 'center' }}>
              <LanguageSwitch />
            </div>
            <p className="tiny muted" style={{ marginTop: 6 }}>
              {LOCALES.map((l) => l.label).join(' · ')}
            </p>
          </div>

          {msg && <div className="alert alert-info">{msg}</div>}

          <form onSubmit={submit}>
            {tab === 'signup' && (
              <>
                <label className="field">
                  <span className="label">{t('auth.name')}</span>
                  <input className="input" value={name} onChange={(e) => setName(e.target.value)} placeholder="Ana" />
                </label>
                <label className="field">
                  <span className="label">{t('auth.storeName')}</span>
                  <input
                    className="input"
                    value={storeName}
                    onChange={(e) => setStoreName(e.target.value)}
                    placeholder="Padaria do Bairro"
                  />
                </label>
              </>
            )}
            <label className="field">
              <span className="label">{t('auth.email')}</span>
              <input
                className="input"
                type="email"
                required
                value={email}
                onChange={(e) => setEmail(e.target.value)}
                placeholder="voce@email.com"
                autoComplete="email"
              />
            </label>
            <label className="field">
              <span className="label">{t('auth.password')}</span>
              <input
                className="input"
                type="password"
                required
                minLength={6}
                value={password}
                onChange={(e) => setPassword(e.target.value)}
                placeholder="••••••"
                autoComplete={tab === 'signup' ? 'new-password' : 'current-password'}
              />
            </label>

            <button className="btn btn-primary btn-block" disabled={busy}>
              {busy ? <span className="spinner" /> : null}
              {tab === 'signup' ? t('auth.signupCta') : t('auth.loginCta')}
            </button>
          </form>

          <div className="center muted small" style={{ margin: '12px 0' }}>
            {t('auth.orWith')}
          </div>

          <button className="btn btn-ghost btn-block" onClick={google} type="button">
            🔐 {t('auth.google')}
          </button>

          <div style={{ marginTop: 12 }}>
            <button className="btn btn-ghost btn-block" onClick={demo} type="button" disabled={busy}>
              🧪 {t('auth.demoBtn')}
            </button>
            <p className="tiny muted center" style={{ marginTop: 8 }}>
              {t('auth.demoNote')}
            </p>
          </div>

          <div className="center" style={{ marginTop: 14 }}>
            <button
              type="button"
              className="btn btn-ghost btn-sm"
              onClick={() => setTab(tab === 'signup' ? 'login' : 'signup')}
            >
              {tab === 'signup' ? t('auth.toLogin') : t('auth.toSignup')}
            </button>
          </div>
        </div>

        <p className="center small muted" style={{ marginTop: 14 }}>
          <Link href="/planos">{t('plans.title')} →</Link>
        </p>
      </div>
    </AppShell>
  );
}

export default function EntrarPage() {
  return (
    <Suspense fallback={<div className="page wrap center">…</div>}>
      <EntrarInner />
    </Suspense>
  );
}
