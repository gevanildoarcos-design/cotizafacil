'use client';

import { useEffect, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import { useApp } from '@/components/AppProvider';
import { payments as paymentsRepo, profiles } from '@/lib/repo';
import { formatDate } from '@/lib/i18n';
import { formatBRL, getPlan, priceFor } from '@/lib/plans';
import type { Payment } from '@/lib/types';

export default function AssinaturaPage() {
  const { t, locale, user, profile, setProfile, toast } = useApp();
  const [history, setHistory] = useState<Payment[]>([]);
  const [busy, setBusy] = useState(false);

  useEffect(() => {
    if (!user) return;
    paymentsRepo.list(user.id).then(setHistory).catch(() => {});
  }, [user?.id]);

  if (!profile) {
    return (
      <AppShell title={t('sub.title')} requireAuth>
        <div className="center" style={{ padding: 40 }}>
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      </AppShell>
    );
  }

  const plan = getPlan(profile.plan);
  const price = priceFor(plan, profile.billing_cycle);
  const statusKey =
    profile.subscription_status === 'active'
      ? 'sub.statusActive'
      : profile.subscription_status === 'past_due'
        ? 'sub.statusPastDue'
        : profile.subscription_status === 'canceled'
          ? 'sub.statusCanceled'
          : 'sub.statusInactive';

  const badgeClass =
    profile.subscription_status === 'active'
      ? 'badge-paid'
      : profile.subscription_status === 'past_due'
        ? 'badge-warn'
        : 'badge-pending';

  async function cancel() {
    if (!confirm(t('sub.cancelConfirm'))) return;
    setBusy(true);
    try {
      // 1) cancela no gateway, quando configurado
      if (profile.subscription_status === 'active') {
        await fetch('/api/subscription/cancel', { method: 'POST' }).catch(() => {});
      }
      // 2) volta ao plano gratuito (webhook também faz isso em produção)
      const patch = await profiles.update({
        plan: 'free',
        subscription_status: 'canceled',
        next_charge_at: null,
      });
      setProfile(patch);
      toast(t('sub.canceled'), 'info');
    } finally {
      setBusy(false);
    }
  }

  async function reactivate(planId: 'starter' | 'complete' | 'growth') {
    setBusy(true);
    try {
      const res = await fetch('/api/checkout', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({ plan: planId, cycle: profile.billing_cycle, locale }),
      });
      const data = await res.json();
      if (data?.url) window.location.href = data.url;
      else toast(data?.error || t('sub.checkoutError'), 'warn');
    } finally {
      setBusy(false);
    }
  }

  return (
    <AppShell title={t('sub.title')} subtitle={t('plans.sub')} requireAuth>
      <div className="grid grid-2">
        <div className="card">
          <div className="row-between">
            <h3 style={{ marginBottom: 0 }}>
              {plan.emoji} {t('sub.currentPlan')}
            </h3>
            <span className={`badge ${badgeClass}`}>{t(statusKey)}</span>
          </div>

          <div className="list-item">
            <span className="list-sub">{t('plans.title')}</span>
            <strong>{t(plan.i18nName)}</strong>
          </div>
          <div className="list-item">
            <span className="list-sub">{t('sub.value')}</span>
            <strong>{price === 0 ? t('sub.noCharge') : `${formatBRL(price)} ${profile.billing_cycle === 'annual' ? t('plans.perYear') : t('plans.perMonth')}`}</strong>
          </div>
          <div className="list-item">
            <span className="list-sub">{t('plans.title')} · {t('sub.status')}</span>
            <strong>{profile.billing_cycle === 'annual' ? t('sub.billingAnnual') : t('sub.billingMonthly')}</strong>
          </div>
          <div className="list-item">
            <span className="list-sub">{t('sub.nextCharge')}</span>
            <strong>{profile.next_charge_at ? formatDate(profile.next_charge_at, locale) : t('sub.noCharge')}</strong>
          </div>

          <div className="actions" style={{ marginTop: 14 }}>
            <Link href="/planos" className="btn btn-brown btn-sm">
              🔄 {t('sub.changePlan')}
            </Link>
            {profile.plan === 'free' ? (
              <button className="btn btn-primary btn-sm" onClick={() => reactivate('starter')} disabled={busy}>
                ⭐ {t('quote.limitReachedCta')}
              </button>
            ) : (
              <button className="btn btn-danger btn-sm" onClick={cancel} disabled={busy}>
                ✖️ {t('sub.cancel')}
              </button>
            )}
          </div>
        </div>

        <div className="card">
          <h3>🧾 {t('sub.history')}</h3>
          {history.length === 0 ? (
            <p className="muted small">{t('sub.historyEmpty')}</p>
          ) : (
            <div className="table-wrap">
              <table className="table">
                <thead>
                  <tr>
                    <th>{t('sub.paymentDate')}</th>
                    <th>{t('sub.paymentAmount')}</th>
                    <th>{t('sub.paymentStatus')}</th>
                  </tr>
                </thead>
                <tbody>
                  {history.map((p) => (
                    <tr key={p.id}>
                      <td>{formatDate(p.paid_at, locale)}</td>
                      <td>
                        {formatBRL(p.amount)}
                        {p.plan_id ? ` · ${t(getPlan(p.plan_id).i18nName)}` : ''}
                      </td>
                      <td>
                        <span className={`badge ${p.status === 'paid' ? 'badge-paid' : 'badge-pending'}`}>
                          {p.status}
                        </span>
                      </td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
          )}
        </div>
      </div>

      <div className="alert alert-info section small">🔔 {t('settings.notificationsHint')}</div>
    </AppShell>
  );
}
