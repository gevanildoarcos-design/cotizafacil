'use client';

import { useEffect, useMemo, useState } from 'react';
import Link from 'next/link';
import AppShell from '@/components/AppShell';
import Calendar from '@/components/Calendar';
import QuoteCard from '@/components/QuoteCard';
import { useApp } from '@/components/AppProvider';
import { quotes } from '@/lib/repo';
import type { Quote, QuoteStatus } from '@/lib/types';

type Filter = 'all' | QuoteStatus;

export default function HistoricoPage() {
  const { t, user } = useApp();
  const [list, setList] = useState<Quote[]>([]);
  const [view, setView] = useState<'list' | 'calendar'>('list');
  const [filter, setFilter] = useState<Filter>('all');
  const [loading, setLoading] = useState(true);

  async function load() {
    if (!user) return;
    setLoading(true);
    try {
      setList(await quotes.list(user.id));
    } finally {
      setLoading(false);
    }
  }

  useEffect(() => {
    void load();
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [user?.id]);

  const filtered = useMemo(
    () => (filter === 'all' ? list : list.filter((q) => q.status === filter)),
    [list, filter],
  );

  const counts = useMemo(
    () => ({
      all: list.length,
      pending: list.filter((q) => q.status === 'pending').length,
      paid: list.filter((q) => q.status === 'paid').length,
      delivered: list.filter((q) => q.status === 'delivered').length,
    }),
    [list],
  );

  const FILTERS: { id: Filter; key: string; n: number }[] = [
    { id: 'all', key: 'history.filterAll', n: counts.all },
    { id: 'pending', key: 'history.filterPending', n: counts.pending },
    { id: 'paid', key: 'history.filterPaid', n: counts.paid },
    { id: 'delivered', key: 'history.filterDelivered', n: counts.delivered },
  ];

  return (
    <AppShell
      title={t('history.title')}
      subtitle={t('history.sub')}
      requireAuth
      action={
        <Link href="/novo" className="btn btn-primary">
          ➕ {t('nav.new')}
        </Link>
      }
    >
      <div className="row-between section" style={{ marginBottom: 14 }}>
        <div className="lang-switch">
          <button type="button" aria-pressed={view === 'list'} onClick={() => setView('list')}>
            ☰ {t('history.list')}
          </button>
          <button type="button" aria-pressed={view === 'calendar'} onClick={() => setView('calendar')}>
            📅 {t('history.calendar')}
          </button>
        </div>

        <div className="chips">
          {FILTERS.map((f) => (
            <button
              key={f.id}
              className="chip"
              aria-pressed={filter === f.id}
              onClick={() => setFilter(f.id)}
            >
              {t(f.key)} <span className="tiny">({f.n})</span>
            </button>
          ))}
        </div>
      </div>

      {loading ? (
        <div className="center" style={{ padding: 40 }}>
          <div className="spinner" style={{ margin: '0 auto' }} />
        </div>
      ) : view === 'calendar' ? (
        <Calendar quotes={filtered} />
      ) : filtered.length === 0 ? (
        <div className="card center">
          <p className="muted">{t('history.empty')}</p>
          <Link href="/novo" className="btn btn-primary">
            {t('history.emptyCta')}
          </Link>
        </div>
      ) : (
        <div className="grid" style={{ gap: 10 }}>
          {filtered.map((q) => (
            <QuoteCard key={q.id} quote={q} onChanged={load} />
          ))}
        </div>
      )}
    </AppShell>
  );
}
