/* CotizaFácil · service worker (atalho na tela inicial + cache básico do app shell) */
const CACHE = 'cotizafacil-v1';
const SHELL = ['/', '/painel', '/novo', '/historico', '/clientes', '/assinatura', '/manifest.json'];

self.addEventListener('install', (event) => {
  event.waitUntil(caches.open(CACHE).then((c) => c.addAll(SHELL).catch(() => undefined)));
  self.skipWaiting();
});

self.addEventListener('activate', (event) => {
  event.waitUntil(
    caches.keys().then((keys) => Promise.all(keys.filter((k) => k !== CACHE).map((k) => caches.delete(k)))),
  );
  self.clients.claim();
});

self.addEventListener('fetch', (event) => {
  const { request } = event;
  if (request.method !== 'GET') return;
  const url = new URL(request.url);
  if (url.origin !== self.location.origin) return;
  if (url.pathname.startsWith('/api/')) return; // APIs sempre na rede

  // network-first com fallback para o cache (funciona mesmo com internet instável)
  event.respondWith(
    fetch(request)
      .then((res) => {
        const copy = res.clone();
        caches.open(CACHE).then((c) => c.put(request, copy)).catch(() => undefined);
        return res;
      })
      .catch(() => caches.match(request).then((hit) => hit || caches.match('/painel'))),
  );
});
