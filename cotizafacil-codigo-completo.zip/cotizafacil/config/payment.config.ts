/**
 * CotizaFácil · configuração do gateway de pagamento / pasarela de pago
 * ---------------------------------------------------------------------
 * Este é o ÚNICO arquivo que você precisa tocar para trocar de gateway.
 * Nenhuma chave secreta fica aqui: tudo vem de variáveis de ambiente.
 *
 * Mercado Pago  -> usa "preapproval" (assinatura recorrente):
 *                  POST /preapproval  { reason, auto_recurring: { frequency, frequency_type, transaction_amount, currency_id }, payer_email, back_url, status: "pending" }
 *                  Docs: https://www.mercadopago.com.br/developers/pt/docs/subscriptions/integration-configuration/subscription-no-associated-plan/authorized-payments
 *                  Webhook: topic "subscription_preapproval" e "subscription_authorized_payment"
 * Stripe        -> usa Checkout Session em mode="subscription" com price recorrente:
 *                  POST /v1/checkout/sessions  { mode: "subscription", line_items, client_reference_id, subscription_data.metadata }
 *                  Docs: https://docs.stripe.com/api/checkout/sessions/create
 *                  Webhook: checkout.session.completed, customer.subscription.updated/deleted, invoice.paid
 */

export type PaymentProvider = 'stripe' | 'mercadopago';

export const paymentConfig = {
  /** Gateway ativo. Defina PAYMENT_PROVIDER no .env.local */
  provider: (process.env.PAYMENT_PROVIDER as PaymentProvider) || 'mercadopago',

  /** Moeda de cobrança (BRL para Brasil, MXN/ARS para Latam) */
  currency: process.env.PAYMENT_CURRENCY || 'BRL',

  /** Dias de teste grátis antes da primeira cobrança (0 = cobra na hora) */
  trialDays: Number(process.env.PAYMENT_TRIAL_DAYS || 0),

  /** Desconto anual: 12 meses pelo preço de 10 (2 meses grátis) */
  annualDiscountMonths: 2,

  /** URL de retorno depois do checkout */
  backUrl: process.env.MP_BACK_URL || `${process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000'}/assinatura`,

  /** URLs de webhook (cadastre exatamente estas no painel do gateway) */
  webhooks: {
    stripe: '/api/webhooks/stripe',
    mercadopago: '/api/webhooks/mercadopago',
  },

  /** Credenciais — sempre via ambiente */
  credentials: {
    stripeSecretKey: process.env.STRIPE_SECRET_KEY || '',
    stripeWebhookSecret: process.env.STRIPE_WEBHOOK_SECRET || '',
    mpAccessToken: process.env.MP_ACCESS_TOKEN || '',
    mpWebhookSecret: process.env.MP_WEBHOOK_SECRET || '',
  },
} as const;

/** true quando o gateway está realmente configurado (senão o app roda em modo demonstração) */
export function isPaymentGatewayConfigured(): boolean {
  const c = paymentConfig.credentials;
  return (
    (paymentConfig.provider === 'stripe' && !!c.stripeSecretKey) ||
    (paymentConfig.provider === 'mercadopago' && !!c.mpAccessToken)
  );
}
