import { paymentConfig } from '@/config/payment.config';

export type PlanId = 'free' | 'starter' | 'complete' | 'growth';
export type BillingCycle = 'monthly' | 'annual';

export interface Plan {
  id: PlanId;
  /** preço mensal em reais */
  monthly: number;
  /** limite de orçamentos por mês (null = ilimitado) */
  quoteLimit: number | null;
  /** número de usuários incluídos */
  users: number;
  emoji: string;
  /** chave i18n do nome e do conjunto de benefícios */
  i18nName: string;
  i18nFeatureKeys: string[];
  /** id do preço no Stripe (env) e código do plano no Mercado Pago */
  stripePriceEnvMonthly?: string;
  stripePriceEnvAnnual?: string;
  highlight?: boolean;
}

export const PLANS: Plan[] = [
  {
    id: 'free',
    monthly: 0,
    quoteLimit: 5,
    users: 1,
    emoji: '🆓',
    i18nName: 'plans.free.name',
    i18nFeatureKeys: ['plans.free.f1', 'plans.free.f2', 'plans.free.f3'],
  },
  {
    id: 'starter',
    monthly: 14.9,
    quoteLimit: null,
    users: 1,
    emoji: '✨',
    i18nName: 'plans.starter.name',
    i18nFeatureKeys: ['plans.starter.f1', 'plans.starter.f2', 'plans.starter.f3', 'plans.starter.f4'],
    stripePriceEnvMonthly: 'NEXT_PUBLIC_STRIPE_PRICE_STARTER_MONTHLY',
    stripePriceEnvAnnual: 'NEXT_PUBLIC_STRIPE_PRICE_STARTER_ANNUAL',
    highlight: true,
  },
  {
    id: 'complete',
    monthly: 29.9,
    quoteLimit: null,
    users: 2,
    emoji: '🏪',
    i18nName: 'plans.complete.name',
    i18nFeatureKeys: [
      'plans.complete.f1',
      'plans.complete.f2',
      'plans.complete.f3',
      'plans.complete.f4',
      'plans.complete.f5',
    ],
    stripePriceEnvMonthly: 'NEXT_PUBLIC_STRIPE_PRICE_COMPLETE_MONTHLY',
    stripePriceEnvAnnual: 'NEXT_PUBLIC_STRIPE_PRICE_COMPLETE_ANNUAL',
  },
  {
    id: 'growth',
    monthly: 49.9,
    quoteLimit: null,
    users: 5,
    emoji: '👑',
    i18nName: 'plans.growth.name',
    i18nFeatureKeys: [
      'plans.growth.f1',
      'plans.growth.f2',
      'plans.growth.f3',
      'plans.growth.f4',
      'plans.growth.f5',
    ],
    stripePriceEnvMonthly: 'NEXT_PUBLIC_STRIPE_PRICE_GROWTH_MONTHLY',
    stripePriceEnvAnnual: 'NEXT_PUBLIC_STRIPE_PRICE_GROWTH_ANNUAL',
  },
];

export const FREE_QUOTE_LIMIT = 5;

export function getPlan(id: string): Plan {
  return PLANS.find((p) => p.id === id) || PLANS[0];
}

/** Preço a cobrar: mensal = valor; anual = 12 × mensal − 2 meses (10 × mensal). */
export function priceFor(plan: Plan, cycle: BillingCycle): number {
  if (plan.monthly === 0) return 0;
  const months = cycle === 'annual' ? 12 - paymentConfig.annualDiscountMonths : 1;
  return round2(plan.monthly * months);
}

export function priceLabel(plan: Plan, cycle: BillingCycle): string {
  return formatBRL(priceFor(plan, cycle));
}

/** Quanto o cliente economiza no plano anual (2 mensalidades). */
export function annualSavings(plan: Plan): number {
  return round2(plan.monthly * paymentConfig.annualDiscountMonths);
}

export function formatBRL(value: number): string {
  return new Intl.NumberFormat('pt-BR', { style: 'currency', currency: 'BRL' }).format(value || 0);
}

export function round2(n: number): number {
  return Math.round(n * 100) / 100;
}

/** Código do plano enviado ao Mercado Pago (reason) — mantém rastreio no webhook. */
export function planReference(planId: PlanId, cycle: BillingCycle): string {
  return `cotizafacil:${planId}:${cycle}`;
}
