'use client';

/**
 * CotizaFácil · geração de PDF no navegador (jsPDF)
 * - usa o logo do estabelecimento quando houver (data URL)
 * - rótulos no idioma do usuário
 * O import do jsPDF é dinâmico para não pesar o carregamento inicial.
 */
import type { Quote, Locale } from './types';
import { createT, formatDate } from './i18n';
import { formatBRL } from './plans';
import { phoneForDisplay } from './whatsapp';

export interface PdfOptions {
  quote: Quote;
  locale: Locale;
  storeName?: string;
  storePhone?: string;
  logoDataUrl?: string | null;
  accentColor?: string;
}

export async function generateQuotePdf(opts: PdfOptions): Promise<void> {
  const { jsPDF } = await import('jspdf');
  const { quote, locale } = opts;
  const t = createT(locale);
  const logo = opts.logoDataUrl || undefined;
  const store = opts.storeName || quote.store_name || t('app.name');

  const doc = new jsPDF({ unit: 'pt', format: 'a4', orientation: 'portrait' });
  const pageW = doc.internal.pageSize.getWidth();
  const M = 48;
  const brown = opts.accentColor || '#6B4226';
  const yellow = '#F5B301';

  // ---- cabeçalho ----
  doc.setFillColor(yellow);
  doc.rect(0, 0, pageW, 8, 'F');

  let y = 64;
  if (logo) {
    try {
      const fmt = /^data:image\/png/i.test(logo) ? 'PNG' : 'JPEG';
      doc.addImage(logo, fmt, M, y - 26, 64, 64, undefined, 'FAST');
    } catch {
      /* logo inválido: segue sem logo */
    }
  }
  const textX = logo ? M + 80 : M;
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(18);
  doc.setTextColor(brown);
  doc.text(store, textX, y);
  y += 18;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor('#7a6a5c');
  if (opts.storePhone) {
    doc.text(phoneForDisplay(opts.storePhone), textX, y);
    y += 14;
  }
  doc.text(`${t('pdf.issuedOn')} ${new Date().toLocaleDateString(locale === 'es' ? 'es-ES' : 'pt-BR')}`, textX, y);

  // bloco direito: nº / título
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(14);
  doc.setTextColor(brown);
  doc.text(t('pdf.quote'), pageW - M, 68, { align: 'right' });
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor('#7a6a5c');
  doc.text(`#${quote.id.slice(0, 8).toUpperCase()}`, pageW - M, 84, { align: 'right' });

  y = Math.max(y, 118) + 10;
  doc.setDrawColor('#EADFCF');
  doc.line(M, y, pageW - M, y);
  y += 26;

  // ---- cliente ----
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor(brown);
  doc.text(t('pdf.customer'), M, y);
  y += 16;
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(11);
  doc.setTextColor('#2b2b2b');
  doc.text(quote.customer_name || '-', M, y);
  y += 15;
  doc.setTextColor('#7a6a5c');
  doc.text(`${t('pdf.phone')}: ${quote.customer_phone ? phoneForDisplay(quote.customer_phone) : '-'}`, M, y);
  y += 26;

  // ---- detalhes do pedido (tabela) ----
  const rows: [string, string][] = [
    [t('pdf.product'), t(`quote.${quote.product}`)],
    [t('pdf.size'), quote.size || '-'],
    [t('pdf.flavor'), quote.flavor || '-'],
    [t('pdf.filling'), quote.filling || '-'],
    [t('pdf.decoration'), quote.decoration || '-'],
    [t('pdf.message'), quote.message || '-'],
    [
      t('pdf.delivery'),
      [formatDate(quote.delivery_date, locale), quote.delivery_time].filter(Boolean).join(' · ') || '-',
    ],
  ];

  const rowH = 26;
  doc.setFillColor('#FFF8EC');
  doc.rect(M, y - 14, pageW - M * 2, rowH * rows.length, 'F');
  rows.forEach((row, i) => {
    const ry = y + i * rowH + 4;
    if (i > 0) {
      doc.setDrawColor('#F0E6D8');
      doc.line(M, ry - 14, pageW - M, ry - 14);
    }
    doc.setFont('helvetica', 'bold');
    doc.setFontSize(10);
    doc.setTextColor('#8a7563');
    doc.text(row[0], M + 10, ry);
    doc.setFont('helvetica', 'normal');
    doc.setFontSize(11);
    doc.setTextColor('#2b2b2b');
    doc.text(doc.splitTextToSize(String(row[1]), 260), pageW - M - 10, ry, { align: 'right' });
  });
  y += rowH * rows.length + 26;

  // ---- total ----
  doc.setFillColor(brown);
  doc.roundedRect(M, y, pageW - M * 2, 54, 8, 8, 'F');
  doc.setFont('helvetica', 'bold');
  doc.setFontSize(12);
  doc.setTextColor('#FFF3D6');
  doc.text(t('pdf.total'), M + 16, y + 33);
  doc.setFontSize(20);
  doc.setTextColor('#FFFFFF');
  doc.text(formatBRL(quote.value), pageW - M - 16, y + 34, { align: 'right' });
  y += 78;

  // ---- rodapé ----
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(10);
  doc.setTextColor('#7a6a5c');
  doc.text(t('pdf.validity'), M, y);
  y += 14;
  doc.setFont('helvetica', 'bold');
  doc.setTextColor(brown);
  doc.text(t('pdf.thanks'), M, y);

  doc.setDrawColor('#EADFCF');
  doc.line(M, 780, pageW - M, 780);
  doc.setFont('helvetica', 'normal');
  doc.setFontSize(9);
  doc.setTextColor('#a49384');
  doc.text(t('pdf.generatedBy'), M, 796);
  if (opts.storePhone) doc.text(phoneForDisplay(opts.storePhone), pageW - M, 796, { align: 'right' });

  const fileName = `${slug(quote.customer_name || 'orcamento')}-${quote.id.slice(0, 6)}.pdf`;
  doc.save(fileName);
}

function slug(s: string) {
  return s
    .normalize('NFD')
    .replace(/[\u0300-\u036f]/g, '')
    .replace(/[^a-zA-Z0-9]+/g, '-')
    .replace(/^-|-$/g, '')
    .toLowerCase();
}
