/**
 * CotizaFácil · link de WhatsApp
 * Formato oficial: https://wa.me/<SOMENTE_DIGITOS>?text=<mensagem_codificada>
 * O número precisa estar em E.164 sem símbolos (ex.: 5511987654321).
 * Docs: https://faq.whatsapp.com/5913398998672934
 */
import type { Quote } from './types';
import { formatBRL } from './plans';

/** Remove tudo que não é dígito e aplica o código do país quando faltar. */
export function normalizePhone(phone: string, defaultCountryCode = '55'): string {
  let digits = (phone || '').replace(/\D/g, '');
  // remove zeros de operadora/DDD nacional no início (ex.: 011...)
  digits = digits.replace(/^0+/, '');
  if (digits.length <= 11) digits = `${defaultCountryCode}${digits}`;
  return digits;
}

export function phoneForDisplay(phone: string): string {
  const d = normalizePhone(phone);
  if (d.length === 13) return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4, 9)}-${d.slice(9)}`;
  if (d.length === 12) return `+${d.slice(0, 2)} (${d.slice(2, 4)}) ${d.slice(4, 8)}-${d.slice(8)}`;
  return `+${d}`;
}

export interface QuoteMessageOptions {
  storeName?: string;
  language?: 'pt' | 'es';
  deliveryDate?: string;
  deliveryTime?: string;
}

/** Mensagem pré-preenchida do orçamento, no idioma do usuário. */
export function buildQuoteMessage(quote: Quote, opts: QuoteMessageOptions = {}): string {
  const lang = opts.language || 'pt';
  const store = opts.storeName || quote.store_name || 'CotizaFácil';
  const date = quote.delivery_date ? formatDate(quote.delivery_date, lang) : '';
  const time = quote.delivery_time || '';

  const L =
    lang === 'es'
      ? {
          greet: `¡Hola ${quote.customer_name}!`,
          intro: `Aquí está tu presupuesto de ${store}:`,
          product: 'Producto',
          size: 'Tipo/Tamaño',
          flavor: 'Sabor',
          filling: 'Relleno',
          decoration: 'Decoración',
          message: 'Mensaje',
          delivery: 'Entrega',
          total: 'Total',
          thanks: 'Cualquier duda, escríbeme por aquí. ¡Gracias!',
        }
      : {
          greet: `Olá, ${quote.customer_name}!`,
          intro: `Segue o orçamento de ${store}:`,
          product: 'Produto',
          size: 'Tipo/Tamanho',
          flavor: 'Sabor',
          filling: 'Recheio',
          decoration: 'Decoração',
          message: 'Mensagem',
          delivery: 'Entrega',
          total: 'Valor',
          thanks: 'Qualquer dúvida, me chama por aqui. Obrigado!',
        };

  const lines: string[] = [
    L.greet,
    L.intro,
    '',
    `• ${L.product}: ${label(quote.product, lang)}`,
    quote.size ? `• ${L.size}: ${quote.size}` : '',
    quote.flavor ? `• ${L.flavor}: ${quote.flavor}` : '',
    quote.filling ? `• ${L.filling}: ${quote.filling}` : '',
    quote.decoration ? `• ${L.decoration}: ${quote.decoration}` : '',
    quote.message ? `• ${L.message}: ${quote.message}` : '',
    date || time ? `• ${L.delivery}: ${[date, time].filter(Boolean).join(' - ')}` : '',
    '',
    `*${L.total}: ${formatBRL(quote.value)}*`,
    '',
    L.thanks,
  ];

  return lines.filter((l) => l !== '').join('\n');
}

/** Monta o link final clicável/abre no app do WhatsApp. */
export function buildWhatsappLink(quote: Quote, opts: QuoteMessageOptions = {}): string {
  const digits = normalizePhone(quote.customer_phone);
  const text = buildQuoteMessage(quote, opts);
  return `https://wa.me/${digits}?text=${encodeURIComponent(text)}`;
}

function label(product: string, lang: 'pt' | 'es'): string {
  const map: Record<string, { pt: string; es: string }> = {
    torta: { pt: 'Torta', es: 'Torta' },
    bolo: { pt: 'Bolo', es: 'Pastel' },
    doces: { pt: 'Doces', es: 'Dulces' },
    pao: { pt: 'Pão especial', es: 'Pan especial' },
    outro: { pt: 'Outro', es: 'Otro' },
  };
  return map[product]?.[lang] || product;
}

function formatDate(iso: string, lang: 'pt' | 'es'): string {
  const d = new Date(`${iso}T12:00:00`);
  if (Number.isNaN(d.getTime())) return iso;
  return d.toLocaleDateString(lang === 'es' ? 'es-ES' : 'pt-BR', {
    day: '2-digit',
    month: '2-digit',
    year: 'numeric',
  });
}
