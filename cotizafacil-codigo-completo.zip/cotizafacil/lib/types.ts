export type Locale = 'pt' | 'es';

export type QuoteStatus = 'pending' | 'paid' | 'delivered';
export type ProductType = 'torta' | 'bolo' | 'doces' | 'pao' | 'outro';
export type PlanId = 'free' | 'starter' | 'complete' | 'growth';
export type BillingCycle = 'monthly' | 'annual';
export type SubscriptionStatus = 'active' | 'past_due' | 'canceled' | 'inactive';

export interface Profile {
  id: string;
  name: string;
  email: string;
  phone?: string;
  language: Locale;
  plan: PlanId;
  billing_cycle: BillingCycle;
  subscription_status: SubscriptionStatus;
  store_name?: string;
  store_phone?: string;
  /** logo da padaria em data URL (base64) ou URL pública */
  store_logo?: string;
  next_charge_at?: string | null;
  reminder_sent_at?: string | null;
  is_demo?: boolean;
}

export interface Client {
  id: string;
  user_id: string;
  name: string;
  phone: string;
  notes?: string;
  created_at?: string;
}

export interface Quote {
  id: string;
  user_id: string;
  client_id?: string | null;
  customer_name: string;
  customer_phone: string;
  product: ProductType;
  size?: string;
  flavor?: string;
  filling?: string;
  decoration?: string;
  message?: string;
  delivery_date?: string; // YYYY-MM-DD
  delivery_time?: string; // HH:mm
  value: number;
  status: QuoteStatus;
  store_name?: string;
  created_at?: string;
}

export interface Payment {
  id: string;
  user_id: string;
  amount: number;
  currency: string;
  status: 'paid' | 'pending' | 'failed' | 'refunded';
  provider: 'stripe' | 'mercadopago' | 'manual';
  provider_payment_id?: string;
  plan_id?: PlanId;
  billing_cycle?: BillingCycle;
  paid_at: string;
}
