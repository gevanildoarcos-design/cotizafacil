import pt from '@/locales/pt.json';
import es from '@/locales/es.json';
import type { Locale } from './types';

export const dictionaries = { pt, es } as const;
export type Dictionary = typeof pt;

export const LOCALES: { id: Locale; flag: string; label: string }[] = [
  { id: 'pt', flag: '🇧🇷', label: 'Português' },
  { id: 'es', flag: '🇪🇸', label: 'Español' },
];

/** Busca "quote.title" dentro do dicionário; devolve a chave se faltar. */
export function translate(locale: Locale, key: string): string {
  const dict = dictionaries[locale] || dictionaries.pt;
  const parts = key.split('.');
  let node: any = dict;
  for (const p of parts) {
    if (node && typeof node === 'object' && p in node) node = node[p];
    else return key;
  }
  return typeof node === 'string' ? node : key;
}

export function createT(locale: Locale) {
  return (key: string, vars?: Record<string, string | number>) => {
    let out = translate(locale, key);
    if (vars) {
      for (const [k, v] of Object.entries(vars)) out = out.replace(`{${k}}`, String(v));
    }
    return out;
  };
}

export function localeDateLocale(locale: Locale) {
  return locale === 'es' ? 'es-ES' : 'pt-BR';
}

export function formatDate(iso: string | null | undefined, locale: Locale) {
  if (!iso) return '';
  const d = new Date(`${String(iso).slice(0, 10)}T12:00:00`);
  if (Number.isNaN(d.getTime())) return String(iso);
  return d.toLocaleDateString(localeDateLocale(locale), { day: '2-digit', month: '2-digit', year: 'numeric' });
}

export function formatLongDate(iso: string | null | undefined, locale: Locale) {
  if (!iso) return '';
  const d = new Date(`${String(iso).slice(0, 10)}T12:00:00`);
  if (Number.isNaN(d.getTime())) return String(iso);
  return d.toLocaleDateString(localeDateLocale(locale), { weekday: 'short', day: '2-digit', month: 'short' });
}
