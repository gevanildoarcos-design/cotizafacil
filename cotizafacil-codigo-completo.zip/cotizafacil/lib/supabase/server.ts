import { createClient, type SupabaseClient } from '@supabase/supabase-js';

/**
 * Cliente administrativo (SOMENTE servidor): usa a service role key e ignora RLS.
 * Use apenas em rotas de API, webhooks e cron.
 */
export function getServiceSupabase(): SupabaseClient | null {
  const url = process.env.NEXT_PUBLIC_SUPABASE_URL || '';
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY || '';
  if (!/^https:\/\/.+\.supabase\.(co|in)$/.test(url) || key.length < 30) return null;
  return createClient(url, key, { auth: { persistSession: false, autoRefreshToken: false } });
}

export function isServerSupabaseConfigured(): boolean {
  return getServiceSupabase() !== null;
}
