'use client';

/**
 * CotizaFácil · camada de dados
 * ---------------------------------------------------------------
 * • Com Supabase configurado  -> auth real (e-mail/senha + Google), Postgres com RLS
 *   e o limite de 5 orçamentos/mês validado por TRIGGER no banco.
 * • Sem Supabase (demo)       -> tudo salvo em localStorage do aparelho.
 * A interface é a mesma, então nenhuma tela precisa saber onde os dados estão.
 */
import type { Client, Payment, Profile, Quote, PlanId, BillingCycle, Locale } from './types';
import { getSupabase, isSupabaseConfigured } from './supabase/client';
import { FREE_QUOTE_LIMIT } from './plans';

const K = {
  profile: 'cf.profile',
  quotes: 'cf.quotes',
  clients: 'cf.clients',
  payments: 'cf.payments',
  session: 'cf.demo_session',
};

export const DEMO_USER_ID = 'demo-user';

export interface AuthUser {
  id: string;
  email: string;
  name?: string;
  demo: boolean;
}

const emptyProfile = (u: AuthUser, locale: Locale): Profile => ({
  id: u.id,
  name: u.name || 'Padaria',
  email: u.email,
  language: locale,
  plan: 'free',
  billing_cycle: 'monthly',
  subscription_status: 'inactive',
  store_name: u.name || '',
  store_phone: '',
  store_logo: '',
  next_charge_at: null,
  is_demo: u.demo,
});

function read<T>(key: string, fallback: T): T {
  if (typeof window === 'undefined') return fallback;
  try {
    const raw = window.localStorage.getItem(key);
    return raw ? (JSON.parse(raw) as T) : fallback;
  } catch {
    return fallback;
  }
}
function write(key: string, value: unknown) {
  if (typeof window === 'undefined') return;
  window.localStorage.setItem(key, JSON.stringify(value));
}
export const uid = () => Math.random().toString(36).slice(2, 10) + Date.now().toString(36);

function monthStart(d = new Date()) {
  return new Date(d.getFullYear(), d.getMonth(), 1);
}
function isThisMonth(iso?: string) {
  if (!iso) return false;
  const d = new Date(iso);
  return d >= monthStart() && d < new Date(monthStart().getFullYear(), monthStart().getMonth() + 1, 1);
}

/* ============================== AUTH ============================== */

export const auth = {
  async getUser(): Promise<AuthUser | null> {
    const sb = getSupabase();
    if (sb) {
      const { data } = await sb.auth.getUser();
      if (!data?.user) return null;
      return {
        id: data.user.id,
        email: data.user.email || '',
        name: (data.user.user_metadata as any)?.full_name,
        demo: false,
      };
    }
    return read<AuthUser | null>(K.session, null);
  },

  async signUp(email: string, password: string, name: string, locale: Locale): Promise<{ ok: boolean; message?: string; needsConfirm?: boolean }> {
    const sb = getSupabase();
    if (sb) {
      const { data, error } = await sb.auth.signUp({
        email,
        password,
        options: { data: { full_name: name, language: locale }, emailRedirectTo: `${location.origin}/painel` },
      });
      if (error) return { ok: false, message: error.message };
      if (!data.session) return { ok: true, needsConfirm: true };
      return { ok: true };
    }
    const user: AuthUser = { id: DEMO_USER_ID, email, name, demo: true };
    write(K.session, user);
    write(K.profile, emptyProfile(user, locale));
    return { ok: true };
  },

  async signIn(email: string, password: string, locale: Locale): Promise<{ ok: boolean; message?: string }> {
    const sb = getSupabase();
    if (sb) {
      const { error } = await sb.auth.signInWithPassword({ email, password });
      return error ? { ok: false, message: error.message } : { ok: true };
    }
    const user: AuthUser = { id: DEMO_USER_ID, email, name: email.split('@')[0], demo: true };
    write(K.session, user);
    if (!read<Profile | null>(K.profile, null)) write(K.profile, emptyProfile(user, locale));
    return { ok: true };
  },

  async signInWithGoogle() {
    const sb = getSupabase();
    if (!sb) return { ok: false, message: 'Supabase não configurado' };
    const { error } = await sb.auth.signInWithOAuth({
      provider: 'google',
      options: { redirectTo: `${location.origin}/painel` },
    });
    return error ? { ok: false, message: error.message } : { ok: true };
  },

  async signInDemo(locale: Locale) {
    const user: AuthUser = { id: DEMO_USER_ID, email: 'demo@cotizafacil.app', name: 'Padaria Demo', demo: true };
    write(K.session, user);
    if (!read<Profile | null>(K.profile, null)) write(K.profile, emptyProfile(user, locale));
    return user;
  },

  async signOut() {
    const sb = getSupabase();
    if (sb) await sb.auth.signOut();
    if (typeof window !== 'undefined') window.localStorage.removeItem(K.session);
  },

  async resetPassword(email: string) {
    const sb = getSupabase();
    if (!sb) return { ok: false, message: 'Supabase não configurado' };
    const { error } = await sb.auth.resetPasswordForEmail(email, { redirectTo: `${location.origin}/entrar` });
    return error ? { ok: false, message: error.message } : { ok: true };
  },
};

/* ============================ PERFIL ============================ */

export const profiles = {
  async get(user: AuthUser, locale: Locale): Promise<Profile> {
    const sb = getSupabase();
    if (sb) {
      const { data } = await sb.from('profiles').select('*').eq('id', user.id).maybeSingle();
      if (data) return data as Profile;
      const p = emptyProfile(user, locale);
      await sb.from('profiles').upsert({ ...p, id: user.id });
      return p;
    }
    return read<Profile>(K.profile, emptyProfile(user, locale));
  },
  async update(patch: Partial<Profile>): Promise<Profile> {
    const sb = getSupabase();
    if (sb) {
      const { data: u } = await sb.auth.getUser();
      const { data, error } = await sb.from('profiles').update(patch).eq('id', u!.user!.id).select().single();
      if (error) throw error;
      return data as Profile;
    }
    const current = read<Profile | null>(K.profile, null);
    const next = { ...(current as Profile), ...patch } as Profile;
    write(K.profile, next);
    return next;
  },
};

/* ============================ CLIENTES ============================ */

export const clients = {
  async list(userId: string): Promise<Client[]> {
    const sb = getSupabase();
    if (sb) {
      const { data } = await sb.from('clients').select('*').order('created_at', { ascending: false });
      return (data || []) as Client[];
    }
    return read<Client[]>(K.clients, []).filter((c) => c.user_id === userId);
  },
  async save(client: Partial<Client> & { name: string; phone: string }, userId: string): Promise<Client> {
    const sb = getSupabase();
    const record: Client = {
      id: client.id || uid(),
      user_id: userId,
      name: client.name,
      phone: client.phone,
      notes: client.notes || '',
      created_at: client.created_at || new Date().toISOString(),
    };
    if (sb) {
      const { data, error } = await sb.from('clients').upsert(record).select().single();
      if (error) throw error;
      return data as Client;
    }
    const all = read<Client[]>(K.clients, []);
    const idx = all.findIndex((c) => c.id === record.id);
    if (idx >= 0) all[idx] = record;
    else all.unshift(record);
    write(K.clients, all);
    return record;
  },
  async remove(id: string) {
    const sb = getSupabase();
    if (sb) await sb.from('clients').delete().eq('id', id);
    else write(K.clients, read<Client[]>(K.clients, []).filter((c) => c.id !== id));
  },
  /** Cria/reaproveita o cliente pelo telefone ao salvar um orçamento. */
  async ensure(name: string, phone: string, userId: string, notes?: string): Promise<Client> {
    const all = await clients.list(userId);
    const digits = (p: string) => (p || '').replace(/\D/g, '');
    const found = all.find((c) => digits(c.phone) && digits(c.phone) === digits(phone));
    if (found) {
      const merged = { ...found, name: name || found.name, notes: notes ?? found.notes };
      return clients.save(merged, userId);
    }
    return clients.save({ name, phone, notes: notes || '' }, userId);
  },
};

/* =========================== ORÇAMENTOS =========================== */

export interface Quota {
  plan: PlanId;
  used: number;
  limit: number | null;
  reached: boolean;
}

export const quotes = {
  async list(userId: string): Promise<Quote[]> {
    const sb = getSupabase();
    if (sb) {
      const { data } = await sb.from('quotes').select('*').order('created_at', { ascending: false });
      return (data || []) as Quote[];
    }
    return read<Quote[]>(K.quotes, []).filter((q) => q.user_id === userId);
  },

  async create(input: Partial<Quote>, userId: string): Promise<Quote> {
    const record: Quote = {
      id: input.id || uid(),
      user_id: userId,
      client_id: input.client_id || null,
      customer_name: input.customer_name || '',
      customer_phone: input.customer_phone || '',
      product: input.product || 'bolo',
      size: input.size || '',
      flavor: input.flavor || '',
      filling: input.filling || '',
      decoration: input.decoration || '',
      message: input.message || '',
      delivery_date: input.delivery_date || null,
      delivery_time: input.delivery_time || '',
      value: Number(input.value || 0),
      status: input.status || 'pending',
      store_name: input.store_name || '',
      created_at: input.created_at || new Date().toISOString(),
    };
    const sb = getSupabase();
    if (sb) {
      const { data, error } = await sb.from('quotes').upsert(record).select().single();
      if (error) throw new Error(error.message);
      return data as Quote;
    }
    const all = read<Quote[]>(K.quotes, []);
    all.unshift(record);
    write(K.quotes, all);
    return record;
  },

  async update(id: string, patch: Partial<Quote>): Promise<void> {
    const sb = getSupabase();
    if (sb) {
      const { error } = await sb.from('quotes').update(patch).eq('id', id);
      if (error) throw new Error(error.message);
      return;
    }
    const all = read<Quote[]>(K.quotes, []);
    const idx = all.findIndex((q) => q.id === id);
    if (idx >= 0) {
      all[idx] = { ...all[idx], ...patch };
      write(K.quotes, all);
    }
  },

  async remove(id: string) {
    const sb = getSupabase();
    if (sb) await sb.from('quotes').delete().eq('id', id);
    else write(K.quotes, read<Quote[]>(K.quotes, []).filter((q) => q.id !== id));
  },

  /**
   * Cota do mês. Com Supabase usamos a função my_quota() (mesma regra do trigger).
   * Sem Supabase contamos localmente — o trigger do banco é a trava real quando
   * o projeto está conectado, então não dá para furar o limite pela interface.
   */
  async quota(profile: Profile, userId: string): Promise<Quota> {
    const sb = getSupabase();
    if (sb) {
      const { data } = await sb.rpc('my_quota');
      const row = Array.isArray(data) ? data[0] : data;
      if (row) {
        const limit = row.quota === null || row.quota === undefined ? null : Number(row.quota);
        return { plan: row.plan as PlanId, used: Number(row.used || 0), limit, reached: limit !== null && Number(row.used) >= limit };
      }
    }
    const used = (await quotes.list(userId)).filter((q) => isThisMonth(q.created_at)).length;
    const limit = profile?.plan === 'free' || !profile?.plan ? FREE_QUOTE_LIMIT : null;
    return { plan: profile?.plan || 'free', used, limit, reached: limit !== null && used >= limit };
  },
};

/* =========================== PAGAMENTOS =========================== */

export const payments = {
  async list(userId: string): Promise<Payment[]> {
    const sb = getSupabase();
    if (sb) {
      const { data } = await sb.from('payments').select('*').order('paid_at', { ascending: false });
      return (data || []) as Payment[];
    }
    return read<Payment[]>(K.payments, []).filter((p) => p.user_id === userId);
  },
  async add(p: Omit<Payment, 'id'>): Promise<Payment> {
    const record: Payment = { id: uid(), ...p };
    const sb = getSupabase();
    if (sb) {
      const { data, error } = await sb.from('payments').insert(record).select().single();
      if (error) throw error;
      return data as Payment;
    }
    const all = read<Payment[]>(K.payments, []);
    all.unshift(record);
    write(K.payments, all);
    return record;
  },
};

/* ==================== ASSINATURA (modo demonstração) ==================== */

/**
 * Ativa/atualiza o plano sem gateway (demo). Em produção quem grava é o webhook,
 * com a service role key. Usado aqui apenas quando o gateway não está configurado.
 */
export async function activatePlanLocal(
  profile: Profile,
  plan: PlanId,
  cycle: BillingCycle,
  amount: number,
  addPayment: (p: Omit<Payment, 'id'>) => Promise<Payment>,
): Promise<Partial<Profile>> {
  const next = new Date();
  next.setMonth(next.getMonth() + (cycle === 'annual' ? 12 : 1));
  const patch: Partial<Profile> = {
    plan,
    billing_cycle: cycle,
    subscription_status: plan === 'free' ? 'inactive' : 'active',
    next_charge_at: plan === 'free' ? null : next.toISOString(),
  };
  await profiles.update(patch);
  if (plan !== 'free' && amount > 0) {
    await addPayment({
      user_id: profile.id,
      amount,
      currency: 'BRL',
      status: 'paid',
      provider: 'manual',
      plan_id: plan,
      billing_cycle: cycle,
      paid_at: new Date().toISOString(),
    });
  }
  return patch;
}

export { isSupabaseConfigured };
