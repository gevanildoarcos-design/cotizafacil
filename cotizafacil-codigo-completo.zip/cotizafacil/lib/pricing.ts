/**
 * CotizaFácil · sugestão de preço
 * ---------------------------------------------------------------
 * Regra simples e transparente, pensada para quem vende bolo por encomenda:
 *   valor = preço base do produto + adicionais (tamanho, recheio, decoração) × quantidade
 * Todos os valores em reais e totalmente editáveis no arquivo.
 */
import type { ProductType } from './types';
import { round2 } from './plans';

export const BASE_PRICE: Record<ProductType, number> = {
  torta: 90,
  bolo: 120,
  doces: 60,
  pao: 25,
  outro: 50,
};

/** Adicional por faixa de tamanho — detectado pelas palavras no campo "Tipo/Tamanho". */
export const SIZE_ADDON_WORDS: { words: string[]; addon: number }[] = [
  { words: ['mini', 'pequen', 'small', 'chico', 'pp'], addon: -10 },
  { words: ['grande', 'large', 'big', 'gg', 'festa'], addon: 30 },
  { words: ['kg'], addon: 45 },
  { words: ['unidade', 'un', 'docinho', 'dulce'], addon: 0.8 },
];

export const FILLING_ADDON = 15;
export const DECORATION_ADDON = 25;

export interface SuggestionInput {
  product: ProductType;
  size?: string;
  filling?: string;
  decoration?: string;
  /** quantidade de itens (ex.: 50 docinhos) */
  quantity?: number;
}

export function suggestPrice(input: SuggestionInput): number {
  let value = BASE_PRICE[input.product] ?? 50;
  const size = (input.size || '').toLowerCase();

  for (const rule of SIZE_ADDON_WORDS) {
    if (rule.words.some((w) => size.includes(w))) {
      value += rule.addon;
      break;
    }
    // tamanho tipo "20 cm" -> acrescenta 2 por cm acima de 15 cm
    const cm = /(\d{2})\s*cm/.exec(size);
    if (cm) {
      const n = Number(cm[1]);
      if (n > 15) value += (n - 15) * 2;
      break;
    }
  }

  if (input.filling) value += FILLING_ADDON;
  if (input.decoration) value += DECORATION_ADDON;

  const qty = Math.max(1, Number(input.quantity || 1));
  return round2(Math.max(0, value * qty));
}
