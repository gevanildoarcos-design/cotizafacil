import { getPlan } from './plans';
import type { Locale } from './types';

/**
 * CotizaFácil · e-mails transacionais (lembrete de vencimento, confirmação de assinatura)
 * Provedor: Resend (https://resend.com). Configure RESEND_API_KEY e MAIL_FROM.
 * Sem chave configurada o envio é apenas registrado no console (útil em desenvolvimento).
 */

interface ReminderInput {
  to: string;
  name?: string;
  locale: Locale;
  planName: string;
  cycle: 'monthly' | 'annual';
  nextChargeAt: string | null;
  currency: string;
}

export async function sendReminderEmail(input: ReminderInput): Promise<{ ok: boolean; error?: string }> {
  const apiKey = process.env.RESEND_API_KEY || '';
  const from = process.env.MAIL_FROM || 'CotizaFácil <lembretes@coti-facil.com>';
  const plan = getPlan(input.planName);

  const date = input.nextChargeAt
    ? new Date(input.nextChargeAt).toLocaleDateString(input.locale === 'es' ? 'es-ES' : 'pt-BR')
    : '—';

  const pt = {
    subject: `Lembrete: sua assinatura CotizaFácil vence em 3 dias`,
    hello: `Olá${input.name ? `, ${input.name}` : ''}!`,
    body: `Sua assinatura do plano <strong>${plan.id}</strong> será renovada em <strong>${date}</strong>.`,
    note: 'Se quiser alterar ou cancelar o plano, faça isso em "Minha assinatura" — leva menos de 1 minuto.',
    cta: 'Ver minha assinatura',
  };
  const es = {
    subject: `Recordatorio: tu suscripción a CotizaFácil vence en 3 días`,
    hello: `¡Hola${input.name ? `, ${input.name}` : ''}!`,
    body: `Tu suscripción al plan <strong>${plan.id}</strong> se renovará el <strong>${date}</strong>.`,
    note: 'Si quieres cambiar o cancelar el plan, hazlo en "Mi suscripción" — toma menos de 1 minuto.',
    cta: 'Ver mi suscripción',
  };
  const L = input.locale === 'es' ? es : pt;
  const appUrl = process.env.NEXT_PUBLIC_APP_URL || 'http://localhost:3000';

  const html = `
  <div style="font-family:-apple-system,Segoe UI,Roboto,Arial,sans-serif;background:#FFF8EC;padding:28px">
    <div style="max-width:520px;margin:0 auto;background:#fff;border:1px solid #EADFCF;border-radius:16px;overflow:hidden">
      <div style="background:#F5B301;padding:14px 20px;font-weight:800;color:#4A2D19">🧁 CotizaFácil</div>
      <div style="padding:22px 20px;color:#2B2B2B;font-size:16px;line-height:1.6">
        <p style="margin:0 0 12px">${L.hello}</p>
        <p style="margin:0 0 12px">${L.body}</p>
        <p style="margin:0 0 18px;color:#7A6A5C;font-size:14px">${L.note}</p>
        <a href="${appUrl}/assinatura" style="display:inline-block;background:#6B4226;color:#fff;padding:12px 20px;border-radius:999px;text-decoration:none;font-weight:700">${L.cta}</a>
      </div>
      <div style="padding:14px 20px;border-top:1px solid #EADFCF;color:#A49384;font-size:12px">
        CotizaFácil · ${new Date().getFullYear()}
      </div>
    </div>
  </div>`;

  if (!apiKey) {
    console.log('[email:dry-run]', { to: input.to, subject: L.subject });
    return { ok: true };
  }

  try {
    const { Resend } = await import('resend');
    const resend = new Resend(apiKey);
    const { error } = await resend.emails.send({ from, to: input.to, subject: L.subject, html });
    return error ? { ok: false, error: error.message } : { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Erro no envio' };
  }
}

export async function sendSubscriptionConfirmation(input: {
  to: string;
  name?: string;
  locale: Locale;
  planName: string;
}): Promise<{ ok: boolean; error?: string }> {
  const apiKey = process.env.RESEND_API_KEY || '';
  if (!apiKey) {
    console.log('[email:dry-run] confirmação para', input.to);
    return { ok: true };
  }
  const from = process.env.MAIL_FROM || 'CotizaFácil <lembretes@coti-facil.com>';
  const plan = getPlan(input.planName);
  const subject = input.locale === 'es' ? '¡Suscripción confirmada!' : 'Assinatura confirmada!';
  const html = `<p>${input.locale === 'es' ? '¡Gracias!' : 'Obrigado!'} <strong>${plan.id}</strong></p>`;
  try {
    const { Resend } = await import('resend');
    const resend = new Resend(apiKey);
    const { error } = await resend.emails.send({ from, to: input.to, subject, html });
    return error ? { ok: false, error: error.message } : { ok: true };
  } catch (e: any) {
    return { ok: false, error: e?.message || 'Erro no envio' };
  }
}
